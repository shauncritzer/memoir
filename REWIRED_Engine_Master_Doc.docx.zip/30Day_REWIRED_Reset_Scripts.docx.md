**30-DAY REWIRED RESET**

Complete Video Script Package

**The ABCD Framework**

*Awareness • Breakthrough • Change • Decision*

Shaun Critzer • shauncritzer.com • For HeyGen Production Use

| WEEK 1: A — AWARENESS *"See the system clearly for the first time."* Days 1–7 |
| :---: |

| DAY 1 Welcome to the Real Problem ⏱ 7-8 minutes   *🎭 Warm, honest, immediately disarming* |
| :---- |

Hey. I'm Shaun Critzer.

Before I say anything else, I want to say this: I'm glad you're here. And I mean that — not as a script line, not as a hook. I mean it because I know what it took for you to press play on this.

Maybe you've tried things before. Programs, books, strategies, apps. Maybe you've had streaks — good ones — and then watched them collapse. Maybe you're not even sure what you'd call your 'thing.' It might be food. Scrolling. Work. Alcohol. Relationships. Spending. Anger. Checking out. Numbing out.

It doesn't matter what the thing is. What matters is this: you feel like it's bigger than you. And you're tired of that feeling.

So here's what I want to tell you in the first five minutes of Day 1\.

The thing you keep going back to? It's not the problem.

I know that sounds backwards. Stay with me.

For thirteen years of my life, I thought I had an alcohol problem. A porn problem. A rage problem. I thought I was the problem — that I was broken in some fundamental way that other people weren't.

What I didn't know — what nobody told me — was that every single behavior I couldn't stop was my nervous system trying to survive.

Your nervous system is the command center of your entire life. It regulates your emotions, your reactions, your relationships, your decisions. It decides in milliseconds whether you're safe or not. And when it decides you're not safe — even when nothing is actually wrong — it reaches for whatever has worked before to bring you back to baseline.

That's not weakness. That's biology.

The behaviors you're trying to change? They work. That's why you keep doing them. They regulate your nervous system — temporarily. They quiet the noise. They make the anxiety drop, the numbness lift, the pain stop — for a minute, an hour, a night.

The problem isn't that they don't work. The problem is that they don't heal.

And over time, you need more of them to get the same effect. And the gap between who you are when you're regulated and who you become when you're not — that gap gets wider. And the shame gets heavier. And the willpower gets weaker.

That's the loop. And for the next 30 days, we're going to understand it, interrupt it, rewire it, and then make a decision about who you are on the other side of it.

This is not a willpower program. This is not a discipline program. This is not another thing you try and fail at.

This is a nervous system reset.

Here's what I want you to do today — just one thing. Open your workbook and answer this question: What does my nervous system reach for when I feel unsafe? Don't judge the answer. Don't edit it. Just name it.

Because the first step to changing anything is seeing it clearly.

I'll see you tomorrow.

| ✏ | WORKBOOK: What does my nervous system reach for when I feel unsafe? Don't judge the answer. Just name it. |
| :---: | :---- |

| DAY 2 Why Your Brain Is Not the Enemy ⏱ 7 minutes   *🎭 Educational, validating, science-grounded but human* |
| :---- |

Yesterday I asked you to name what your nervous system reaches for when you feel unsafe.

Today I want to tell you why it reaches for those things — and why your brain is actually doing its job perfectly. It's just doing a job that doesn't serve you anymore.

Let's talk about the brain for a minute. Not in a textbook way — in a way that actually explains your life.

You have a part of your brain called the amygdala. Think of it as your internal smoke detector. Its entire job is to scan for threat, and when it finds one — or thinks it finds one — it fires an alarm. Heart rate up. Cortisol flooding your system. Full alert.

Here's the thing about the amygdala: it doesn't know the difference between a lion chasing you and a text message from your boss. It doesn't know the difference between a childhood trauma being replayed and a present-day argument with your partner. It just fires.

And when it fires, it bypasses your prefrontal cortex — the part of your brain that makes rational decisions — and goes straight to survival mode.

That's why in your most triggered moments you do things you don't understand later. You reach for the phone. You pick the fight. You say yes when you meant no, or no when you meant yes. You disappear.

It's not a character flaw. It's a hijacked brain.

Now here's where it gets interesting. Your brain learns. It's brilliant at learning. And what it learned — probably a long time ago — is that certain behaviors bring the alarm down. They regulate the system. They tell the amygdala: we're okay, we survived.

The problem is your brain learned those lessons in a different context. Maybe as a kid, numbing out was the only option you had. Maybe shutting down kept you safe. Maybe anger was the only power you had.

Those strategies made sense then. They don't serve you now. But your brain is still running them — automatically, reflexively — because that's what it learned.

Neuroplasticity is the word that changes everything here. It means your brain can learn new things. At any age. In any circumstance. The neural pathways that drive your automatic responses are not permanent. They can be changed.

That's what these 30 days are about.

| ✏ | WORKBOOK: What did I learn to do as a kid to feel safe? Am I still doing it today? |
| :---: | :---- |

| DAY 3 The Three States: Which One Are You In Right Now? ⏱ 8 minutes   *🎭 Educational, practical, immediately applicable* |
| :---- |

I want to give you a map today. Not a metaphorical map — an actual framework you can use starting right now to understand what's happening inside you at any given moment.

There's a researcher named Stephen Porges who developed something called Polyvagal Theory. It sounds complicated. It's not. Here's what it actually says in plain language:

Your nervous system has three states. And you move between them all day long, usually without knowing it.

**State One: Safe and Social. This is your baseline. Your heart rate is calm, your breathing is easy, your thinking is clear. You can be present. You can connect. You can make good decisions. You can hear feedback without collapsing. You can disagree without blowing up. This is the state we're trying to help you spend more time in.**

**State Two: Fight or Flight. The alarm went off. Your system mobilized. Heart rate up, cortisol up, breath gets shallow. You become reactive. Defensive. You might get angry, anxious, impulsive. You might pick a fight. You might make a decision you'll regret.**

**State Three: Shutdown. This is what happens when fight or flight has been going too long and your system gives up. You go numb. You dissociate. You check out. The scrolling for hours. The binge eating in a trance. The 'I don't even know why I did that.' This is the freeze response — the nervous system's last resort.**

Here's what's important: every behavior you're trying to change makes perfect sense through this lens. You reach for it when you're in State Two or Three. Because it temporarily brings you back toward State One.

The work isn't to never go into States Two or Three. You will. You're human. The work is to notice when you're there — and have tools to come back.

That's what the next three weeks are about.

| ✏ | WORKBOOK: For the rest of today, check in every few hours: Which state am I in right now? No judgment. Just data. |
| :---: | :---- |

| DAY 4 The Loop Nobody Talks About ⏱ 7-8 minutes   *🎭 Honest, story-forward, relatable* |
| :---- |

I want to tell you about the loop. Not a concept loop. My actual loop. The one that ran my life for over a decade.

It started with a feeling. Usually it was one of three things: loneliness, inadequacy, or a low-level anxiety that I couldn't name. Just this hum underneath everything.

That feeling was a cue. My nervous system recognized it — 'we've been here before, here's what we do' — and it reached. For the drink. For the screen. For the argument. For the gym when I was already exhausted. For the work project at 11pm when my family was asleep.

The behavior would follow. And for a window of time — sometimes 20 minutes, sometimes a few hours — the feeling would drop. I'd be back to baseline. The hum would quiet.

And then the aftermath. The shame. The 'I did it again.' The promise to myself that tomorrow would be different.

And that promise? That shame? Became the new cue.

That's the loop. Feeling → Behavior → Temporary relief → Shame → New feeling → Behavior.

And the trap is in the middle. The temporary relief is real. It's not imaginary. Your behavior genuinely works for a window of time. That's why you keep doing it. You're not stupid. You're not weak. You're chasing something that actually delivers — just not for long, and not without cost.

Understanding the loop doesn't break it. But it's the beginning of breaking it.

You can't interrupt something you can't see.

| ✏ | WORKBOOK: Draw your loop. What's the feeling that starts it? The behavior? The temporary relief? The aftermath? Be specific — the more specific you are, the more power you have. |
| :---: | :---- |

| DAY 5 What Your Body Is Actually Saying ⏱ 8 minutes   *🎭 Somatic, grounding, deeply validating* |
| :---- |

Today we're going into the body. I know that phrase sounds like a yoga class. It's not. This is the most practical thing I'm going to teach you in this entire program.

Here's what I mean when I say your body is talking to you: every emotional state you experience has a physical signature. Every time. Without exception.

Anxiety has a sensation — maybe a tightness in your chest, a hollowness in your stomach, a tension in your jaw. Shame has a sensation — maybe heat in your face, a collapsing in your chest, an urge to disappear. Loneliness has a sensation — maybe an ache behind the sternum, a heaviness in your limbs. Anger has a sensation — heat, pressure, tightening.

Most people walk around completely disconnected from these signals. We live above the neck. We're in our heads, running narratives, analyzing, planning, replaying conversations. And the body is down there, in the dark, screaming — and nobody's home to hear it.

Here's why that matters for what you're working on: your compulsive behaviors almost always get triggered before you consciously register an emotion. The body fires first. The urge comes. And then you go on autopilot.

If you can learn to catch the physical signal before the autopilot kicks in — just a second or two earlier — you create a window. And in that window, there's choice. That window is everything.

| ✏ | WORKBOOK: Sit still for three minutes. Close your eyes. Ask your body: 'What are you feeling right now?' Not your mind — your body. Where do you feel it? What does it feel like? Write it down. |
| :---: | :---- |

| DAY 6 The Identity Behind the Behavior ⏱ 8-9 minutes   *🎭 Deep, introspective, identity-shifting* |
| :---- |

I want to ask you something uncomfortable today. When you do the thing you're trying to stop — who are you in that moment? Not the behavior. The identity. The story you're living in.

Because here's something I learned that broke everything open for me: we don't just have behaviors. We have identities that make those behaviors feel inevitable.

For years, my identity was 'the guy who can handle everything.' Never ask for help. Never show weakness. Push through. Work harder. Be more. And when that identity got too heavy to carry — when the gap between who I was pretending to be and how I actually felt got too wide — I reached for something to close the gap.

My behavior made perfect sense for that identity. It was actually the most logical thing in the world.

So the question isn't just 'how do I stop the behavior?' The question is: 'Who is the person who does this, and is that who I actually want to be?'

James Clear, who wrote Atomic Habits, says the most powerful words you can say when building a new behavior are: 'I am the kind of person who...' Because behavior follows identity. Every time.

If you believe at your core that you're broken, that you're too far gone, that you're someone who always self-destructs — your behavior will confirm that identity. Not because you want it to. Because that's how identity works. The brain is a confirmation machine.

But if you shift the identity — even slightly, even just as an experiment — the behavior starts to shift with it.

| ✏ | WORKBOOK: What identity is underneath my pattern? And what identity do I want to step into instead? Take your time with this one. |
| :---: | :---- |

| DAY 7 What You've Already Survived ⏱ 8 minutes   *🎭 Honoring, powerful, momentum-building* |
| :---- |

You made it to Day 7\. I don't say that lightly. Because I know what a week looks like in the middle of trying to change something real. I know the moments you almost didn't press play. The days the loop won. The mornings you wondered if any of this was going to make a difference.

You're still here. That matters more than you know.

Today I want to talk about what you've already survived. Not as a guilt trip. Not as a 'look how far you've come' motivational poster. But as actual evidence.

You have gotten through every hard day of your life so far. Every single one. A hundred percent success rate. That's not small. That's not nothing.

The nervous system you have — the one that's been running these patterns, reaching for these behaviors, keeping you stuck — that nervous system also got you through things that would have broken other people. It got you through the childhood you didn't choose. The losses you didn't ask for. The versions of yourself you're not proud of.

It kept you alive.

And now you're asking it to do something even harder: to heal. To learn new ways. To trust that there's safety available that it hasn't experienced before.

That takes courage. Real courage. Not the loud kind. The quiet, daily, press-play-again kind.

Week 2 starts tomorrow. We're going to start interrupting the loop. Let's go.

| ✏ | WORKBOOK: Write three things you've survived that you didn't think you would. After each one, write: 'I'm still here.' |
| :---: | :---- |

| WEEK 2: B — BREAKTHROUGH *"Interrupt the pattern. Crack the loop open."* Days 8–14 |
| :---: |

| DAY 8 The Pause Is the Practice ⏱ 7 minutes   *🎭 Practical, activating, tool-focused* |
| :---- |

Welcome to Week 2\. Last week was about seeing the system. This week is about interrupting it. And I want to start with the most important skill in this entire program. The pause.

I know. You've heard 'just pause before you react.' You've probably tried it. And in the moment — when the craving is up, when the trigger has fired, when your nervous system is flooded — the pause feels impossible.

So let me teach you what the pause actually is, physiologically. Because when you understand what's happening in your body, you can use it.

When your amygdala fires the alarm, it takes approximately 90 seconds for the chemical response — the cortisol, the adrenaline — to flush through your bloodstream. Ninety seconds. Dr. Jill Bolte Taylor, the neuroscientist, documented this.

Ninety seconds. If you can ride the wave for 90 seconds without acting on it — without feeding it with a story — it starts to drop.

Here's what feeding it looks like: 'I knew I couldn't do this. I always do this. I'm never going to change.' That narrative extends the wave. It adds chemical to chemical.

Here's what riding it looks like: You notice the sensation in your body. You name it. You breathe. You wait. Ninety seconds.

The pause is a skill. And skills require practice before the game.

| ✏ | WORKBOOK: Set an alarm for 90 seconds right now. Sit with it. Do nothing. Just breathe and wait. Practice the pause before you need it. |
| :---: | :---- |

| DAY 9 Trigger Mapping: Know Your Landmines ⏱ 8 minutes   *🎭 Strategic, clear, empowering* |
| :---- |

Today we're making a map of your landmines. Not to avoid them forever — that's not possible, and trying to is its own kind of trap. But to stop being surprised by them.

A trigger is any stimulus — internal or external — that moves your nervous system from State One into State Two or Three. And triggers are specific. They're personal. And they're often hiding in plain sight.

Let me give you mine. Because specificity matters more than a generic list.

**People. Certain people dysregulate me almost instantly. Someone who dismisses me. Someone who reminds me of a dynamic from childhood. Someone whose success makes me feel small, or whose chaos pulls me in.**

**Places. Specific environments that my nervous system associated with old patterns. Certain bars, obviously. But also — specific rooms in my house at specific times of day. The office late at night. The car alone on a long drive.**

**Emotions. Loneliness was my biggest one. Not sadness — loneliness. That specific feeling of being fundamentally unseen. Also inadequacy. The feeling of not being enough.**

**Times. Thursday nights. Sunday afternoons. The hour after a hard conversation. 10pm when the house got quiet.**

These are specific. Because the nervous system is specific. It learned these associations in specific contexts. The goal isn't to avoid your triggers. The goal is to know them so they stop ambushing you.

| ✏ | WORKBOOK: Create your trigger map. Four columns: People, Places, Emotions, Times. Fill in what you know. This is a living document — you'll add to it. |
| :---: | :---- |

| DAY 10 The STOP Tool: Your Four-Second Circuit Breaker ⏱ 7 minutes   *🎭 Tool-focused, practical, immediately usable* |
| :---- |

Today I'm giving you a tool you can use in the next 24 hours. It's called STOP. It comes from mindfulness-based stress reduction, and it works. Not because it's complicated. Because it's simple enough to actually remember when your brain is flooded.

**S — Stop. Whatever you're doing, whatever chain of thought you're in, whatever action you're about to take — stop. Physically. Just stop.**

**T — Take a breath. One conscious breath. Not a meditation session. One breath, in through the nose, out through the mouth. This activates your parasympathetic nervous system — the brake pedal. It's physiology, not woo.**

**O — Observe. What's happening right now? In your body, not in your story. Where do you feel the activation? What does it feel like? Is it in your chest? Your stomach? Your jaw? Just notice. No judgment, no fixing.**

**P — Proceed with awareness. Now you can act. But you're acting from a slightly more regulated place than you were three seconds ago. That's the whole game.**

This is not going to feel natural the first time. Or the tenth time. Your nervous system has been running on autopilot for years. This is you installing a new circuit. Expect it to feel awkward. Do it anyway.

| ✏ | WORKBOOK: Use the STOP tool at least three times today. Start with small things — traffic, a frustrating email, a moment of boredom. Build the muscle before the test. |
| :---: | :---- |

| DAY 11 Breathwork: The Only Tool That Works in Real Time ⏱ 9 minutes   *🎭 Science-backed, practical, includes live practice* |
| :---- |

I want to talk about breath today. Not in a spiritual way. In a neuroscience way. Because breath is the only autonomic function you can consciously control. And that control is a direct line to your nervous system.

When you consciously change your breath, you change your nervous system state. This is measurable physiology.

There's a nerve called the vagus nerve. It's the longest nerve in your body, running from your brainstem through your heart and lungs and gut. It's the primary conduit of your parasympathetic nervous system — the calm. Extended exhales activate the vagus nerve.

**Tool 1: Box Breathing. Inhale 4 counts, hold 4, exhale 4, hold 4\. Navy SEALs use this before and during high-stress situations.**

**Tool 2: 4-7-8 Breathing. Inhale 4 counts, hold 7, exhale 8\. The long exhale activates parasympathetic response. This is your emergency brake.**

**Tool 3: Physiological Sigh. Double inhale through the nose — short, then top it off — followed by a long exhale through the mouth. Stanford researchers identified this as the fastest single breath pattern to reduce stress. Takes 5 seconds.**

Let's do the physiological sigh right now. Together. Double inhale — in through the nose, and top it off. Good. Now long exhale, all the way out through the mouth. Feel that drop? That's your vagus nerve engaging. That's real.

| ✏ | WORKBOOK: Practice one of the three breath tools when you feel any dysregulation today — even mild. Notice what happens and record it. |
| :---: | :---- |

| DAY 12 The Story Making It Worse ⏱ 8 minutes   *🎭 Cognitive-behavioral meets nervous system science* |
| :---- |

I want to talk about the story today. Because here's something I've noticed: the trigger fires, the nervous system activates — and then the mind immediately starts narrating. And that narration often makes everything significantly worse.

'Of course this happened. This always happens. I knew I couldn't change. I'm just like my father. I'm never going to be different. Why do I even try.'

That story is like pouring gasoline on an already burning fire.

Cognitive scientists call this cognitive fusion. You've fused with your thoughts. You're not having a thought — you are the thought. You're inside it. It's real, it's true, it's the whole world.

And when you're fused with a thought like 'I'll never change' — your nervous system responds to that thought as if it's a threat. Which means it produces more cortisol. More activation. More pull toward the behavior.

ACT therapy calls this defusion — creating distance from your thoughts. Seeing them as mental events rather than facts.

One of the simplest defusion techniques: when the story starts, add the phrase 'I'm having the thought that...' before it. 'I'm having the thought that I'll never change.'

That small phrase creates a tiny bit of space between you and the thought. You're not denying it. You're just observing it from the outside. That space is where your choices live.

| ✏ | WORKBOOK: Catch the story once today. Just once. Add 'I'm having the thought that...' and notice what happens. |
| :---: | :---- |

| DAY 13 Urge Surfing: Ride the Wave Instead of Fighting It ⏱ 8 minutes   *🎭 Counterintuitive, liberating, practice-based* |
| :---- |

Today I'm going to teach you something counterintuitive. What if, instead of fighting the urge — instead of white-knuckling through it, distracting yourself from it, arguing with it — you just rode it?

This is called urge surfing. It was developed by psychologist Alan Marlatt, and decades of research confirm it works better than suppression.

Here's the science: when you try to suppress an urge — when you tell yourself 'don't think about it, don't feel it, don't go there' — the urge gets stronger. This is called the rebound effect. Fighting the urge adds energy to it.

Surfing the urge means you let it rise, observe it, and wait for it to fall. Because every urge has a peak and a drop. Every single one. If you can ride it without acting on it, it will peak and it will drop. Usually in three to ten minutes.

Here's how to surf: Notice the urge arriving. Name it — 'there it is.' Locate it in your body — where is it, what does it feel like? Breathe into it. Don't try to make it go away. Just observe it like you're watching weather. Narrate it: 'The urge is rising now. It's peaking. It's strong right now. It's starting to drop.' Wait.

This takes practice. The first time, you might only last 30 seconds before you act. That's not failure. That's data. Every time you surf a little longer, you're building the neural pathway that makes the next ride easier.

| ✏ | WORKBOOK: When an urge comes today — any urge — try to surf it for as long as you can. Record: how long, what it felt like, what happened. |
| :---: | :---- |

| DAY 14 Halfway: What the Data Is Showing You ⏱ 8 minutes   *🎭 Reflective, celebrating progress honestly* |
| :---- |

You're at the halfway point. Fourteen days. Two full weeks.

I want to stop here and do something important: I want to help you look at your data. Not your wins and losses. Your data.

Because transformation isn't linear. It doesn't look like a straight upward line on a chart. It looks jagged. Three good days and then a crash and then two more good days and then a surprise. Things getting worse before they get better — because when you start shining a light on patterns you've kept in the dark, they get louder before they quiet.

So pull out your workbook and look at the last 14 days honestly.

What worked? What tool actually helped, even once? What surprised you? What came up that you didn't expect? When was the loop the strongest — what was the trigger, what state were you in? When were you most regulated — what were the conditions?

This is your personal data. More valuable than anything I can give you, because it's yours.

Here's what I want you to understand about the halfway point: the fact that you're still here means the discomfort of continuing is less than the discomfort of going back. That's the threshold. That's where change lives.

Week 3 starts tomorrow. We're going to start building the new wiring. Not just interrupting the old. Building the new. I'm proud of you. Let's go.

| ✏ | WORKBOOK: 14-day review: What's the most important thing you learned about your nervous system? What tool did you reach for most? What are you most proud of? |
| :---: | :---- |

| WEEK 3: C — CHANGE *"Build new neural pathways. Regulation over willpower."* Days 15–21 |
| :---: |

| DAY 15 Neuroplasticity: You're Literally Building a New Brain ⏱ 8 minutes   *🎭 Science-forward, hopeful, activating* |
| :---- |

Welcome to Week 3\. This week is about building. Not just stopping the old — building the new.

Your brain changes. Physically. Measurably. Based on what you repeatedly think, feel, and do. This is neuroplasticity. Not a self-help concept. A documented, peer-reviewed, observable fact.

In the 1990s, scientists believed the brain was essentially fixed by adulthood. Then researchers started putting monks with 40,000 hours of meditation in brain scanners. And found something that rewrote the textbooks: the brains of people who repeatedly practiced specific mental and emotional states were structurally different.

More grey matter in areas associated with attention and self-awareness. Less reactivity in the amygdala. Thicker prefrontal cortex. These weren't different brains to begin with. These were brains that had been trained.

Every time you use the STOP tool, you're building a new pathway. Every time you surf an urge instead of acting on it, you're building a new pathway. Every time you breathe instead of react, you're building a new pathway.

These pathways start thin. Like dirt tracks. They feel effortful, unnatural, slow. But with repetition they become paved roads. And eventually highways.

You are literally building a new brain.

| ✏ | WORKBOOK: Name one new behavior you're going to repeat deliberately this week. One thing that represents who you're becoming, not who you've been. That's the seed. Now water it. |
| :---: | :---- |

| DAY 16 The Regulating Lifestyle: Sleep, Movement, Fuel ⏱ 9 minutes   *🎭 Practical, direct, no-nonsense* |
| :---- |

I'm going to talk about the unsexy stuff today. Not because it's boring — because it's foundational. Most transformation programs skip it entirely, and then wonder why people can't sustain the mindset work.

You cannot regulate a dysregulated nervous system with mindset alone if your body is running on no sleep, no movement, and garbage fuel. You're trying to run sophisticated software on a machine that hasn't been charged.

**Sleep. When you're sleep-deprived, your amygdala becomes 60% more reactive. Sixty percent. That means triggers hit harder. Urges are stronger. Regulation is harder. Seven to nine hours isn't a luxury. It's a nervous system requirement.**

**Movement. Your body was designed to move. The stress response — cortisol, adrenaline — was designed to be metabolized through physical action. When you activate and then don't move, that chemistry stays in your body and looks for an exit. Movement doesn't mean an hour in the gym. It means a 20-minute walk. Pushups in your living room. Something that moves the body and processes the chemistry.**

**Fuel. What you eat directly affects your brain chemistry. Blood sugar crashes produce anxiety. Processed foods drive inflammation which drives depression and reactivity. I'm not here to give you a diet. I'm here to tell you that if your fuel is working against your nervous system, you're fighting with both hands tied.**

| ✏ | WORKBOOK: Pick one of the three — sleep, movement, or fuel — and make one specific change today. Just one. Small. Real. |
| :---: | :---- |

| DAY 17 Regulation Tools: Your Personal Toolkit ⏱ 9 minutes   *🎭 Expansive, practical, personalized* |
| :---- |

Today I want to give you a full toolkit. Because what regulates one person's nervous system is different from what regulates another's. Part of this work is discovering what works for you.

**Movement-based regulation: Walking — especially in nature. Running. Weightlifting. Dance. Shaking — literally shaking your body, which is a trauma release practice called TRE. Yoga. Swimming.**

**Sensory regulation: Cold water on the face or a cold shower activates the dive reflex and drops heart rate within seconds. Heat — a hot bath, a sauna. Weighted blankets. Certain scents activate the parasympathetic system directly through the olfactory nerve.**

**Social regulation: Co-regulation — being in the physical presence of someone who is regulated. This is how babies learn to self-regulate, and adults need it too. A real conversation, not a text thread.**

**Creative regulation: Music. Writing. Drawing. Building something with your hands. These engage the prefrontal cortex in ways that quiet the amygdala.**

**Mindfulness-based: Body scan meditation. Simply naming emotions out loud — research shows that labeling a feeling reduces its intensity in the amygdala. Even saying 'I feel angry' reduces the anger. This is called affect labeling.**

| ✏ | WORKBOOK: Build your personal regulation toolkit. Three columns: tools I know work for me, tools I want to try, tools I'm going to use this week. |
| :---: | :---- |

| DAY 18 Relationships: How Dysregulation Destroys Connection ⏱ 9 minutes   *🎭 Honest, intimate, courageous* |
| :---- |

Let's talk about relationships today. Because if you've been dysregulated for a long time — and most of us have — it's left a mark on the people closest to you.

Maybe they've been on the receiving end of your fight state. The anger that came from nowhere. The defensiveness to normal feedback. The need to win the argument.

Maybe they've been on the receiving end of your shutdown state. The withdrawal. The emotional unavailability. The walls. The person who was physically present but completely gone.

I want to say something that's hard and important: your nervous system dysregulation is not an excuse for the harm it's caused. Understanding it doesn't erase the impact. But it does give you a path to actually change — which is what the people who love you need. Not another apology. A different pattern.

When you're in State Two or Three, you cannot actually see another person. You're too busy surviving. You react to who you imagine they are, not who they actually are.

What does showing up differently look like? It looks like pausing before you respond when activated. Saying 'I need five minutes to regulate before we continue this conversation.' Repairing after rupture instead of pretending it didn't happen. Being present. Showing up to the conversation instead of just showing up to the room.

| ✏ | WORKBOOK: Name one relationship affected by your dysregulation. Write one specific thing you can do differently this week. Not a grand gesture. One thing. |
| :---: | :---- |

| DAY 19 Money and the Nervous System (Yes, Really) ⏱ 8 minutes   *🎭 Bold, science-backed, personally vulnerable* |
| :---- |

This might be the video that surprises you most. We're going to talk about money. Not investment strategy. We're going to talk about why your nervous system is probably running your financial life — and not in the direction you want.

Your relationship with money is a nervous system response.

The compulsive spending when you're stressed — that's a regulation behavior. The same neural circuitry that drives any other self-soothing pattern drives the shopping, the purchase that gives you a temporary hit of dopamine.

The avoidance of looking at your bank account — that's a shutdown response. Your nervous system has learned that financial information is a threat. So it avoids.

The self-sabotage when you start making more money — for many people, financial safety was never modeled. Abundance didn't feel safe. It felt like a target. So unconsciously, the nervous system dismantles it.

The scarcity thinking even when there's enough — that's hypervigilance. Constantly scanning for the financial threat that might be coming.

For me, the connection was direct. When I was most dysregulated, I spent most. When I was most regulated, I made clear decisions, saved, built. My financial life was a direct readout of my nervous system state. The same tools that help you regulate emotionally will regulate your financial life — if you let them.

| ✏ | WORKBOOK: Where does dysregulation show up in your financial life? Name it honestly. No shame. Just data. |
| :---: | :---- |

| DAY 20 The New Identity: Who You're Becoming ⏱ 9 minutes   *🎭 Identity-forward, powerful, visioning* |
| :---- |

We talked in Week 1 about the identity underneath the pattern. Today I want to talk about the identity you're building.

Because lasting change is not primarily behavioral. It's not primarily habitual. It's primarily about identity. You change when you genuinely believe you are a different kind of person.

Not 'I'm trying to be someone who doesn't do X.' 'I am someone who...'

For years I was 'the addict trying to stay sober.' That identity kept me tethered to the pattern I was trying to leave. My identity was defined by what I was fighting.

At some point I became 'someone whose nervous system is regulated.' Someone who leads with presence. Someone who shows up for his kids differently than his father showed up for him. Someone who has turned his pain into purpose.

That's not a slogan. It's a genuine identity shift. And it changed everything about how I make decisions — not because I'm trying harder, but because I'm operating from a different self-concept.

Identity precedes behavior. Claim the identity. The behavior will follow.

| ✏ | WORKBOOK: Write a paragraph in first person, present tense: 'I am someone who...' Don't write who you want to be someday. Write who you are choosing to be today. Even if it's not fully true yet. Especially if it's not fully true yet. |
| :---: | :---- |

| DAY 21 Three Weeks In: Taking Stock ⏱ 8 minutes   *🎭 Honest, grounding, forward-building* |
| :---- |

Three weeks. I want to be real with you today.

Three weeks is often when the initial momentum wears off. The novelty has faded. The discomfort of continuing is real. And the old patterns — the ones you've been interrupting — they haven't disappeared. They've just gotten quieter. Quieter isn't gone. And some days quiet feels louder than it ever did.

That's normal. That's actually a sign you're on the right track.

Here's something I want you to understand about the timeline of nervous system change: the first three weeks are about creating awareness and beginning to interrupt automatic responses. You're asking your nervous system to do something new and uncomfortable — to not go where it has always gone when the alarm fires.

This creates cognitive load. It feels effortful. Like learning to drive on the other side of the road.

Week 4 is when something shifts. Not for everyone, not all at once. But there is often a moment in the fourth week when something that used to feel effortful begins to feel slightly more natural. Not easy. Natural. That's the new pathway becoming a real pathway.

You're about to enter the most important week of this program. I'll see you there.

| ✏ | WORKBOOK: Three-week review: What's the most important thing you've learned about your nervous system? What tool have you reached for most? What are you most proud of from the last 21 days? |
| :---: | :---- |

| WEEK 4: D — DECISION *"Choose who you are now. Every single day."* Days 22–30 |
| :---: |

| DAY 22 The Decision Is Not One Decision ⏱ 8 minutes   *🎭 Reframing, practical, momentum-forward* |
| :---- |

Welcome to the final week. I called this week DECISION. And I want to immediately tell you what I don't mean.

I don't mean the one big moment where you decide to change your life and everything is different. That moment might happen. But it's not enough on its own.

What I mean by decision is this: the daily, sometimes hourly, sometimes minute-by-minute act of choosing the new over the familiar. That's what the fourth week is about. Not a single dramatic pivot. A thousand small ones.

Transformation is not an event. It's a practice. It's the accumulation of choices that, at first, feel enormous — and over time, feel like who you are.

The first time you surfed an urge instead of acting on it, it probably felt like moving a mountain. Someday — not distant, not theoretical — it will feel like choosing tea instead of coffee. A preference, not a battle.

Here's the decision I want you to make today — not about any specific behavior, but about your fundamental orientation: Are you someone who is still trying to see if this works? Or are you someone who has decided it works and is doing the work? Those are two very different relationships to the process.

| ✏ | WORKBOOK: Write the decision in one sentence: 'I have decided to...' Not 'I want to.' Not 'I'm trying to.' 'I have decided.' The decision is the compass. Everything else is navigation. |
| :---: | :---- |

| DAY 23 When You Fall: Relapse Isn't the End of the Story ⏱ 9 minutes   *🎭 Honest, compassionate, refusing to sugarcoat* |
| :---- |

Let's talk about falling. Because if I don't talk about it, I'm doing you a disservice.

First: falling is not failure. Let me tell you why it's actually true. The nervous system doesn't change in straight lines. It changes the way weather changes — with patterns, with setbacks, with days that look like the old days even after weeks of new ones.

What determines whether you change isn't whether you fall. It's what you do in the next five minutes after you fall.

Because there are two very different five-minute options.

**Option One: the shame spiral. 'I knew I couldn't do this. I've ruined it. What's the point. I might as well...' That sentence, when you finish it, doubles or triples the damage of the original fall. This is the relapse after the relapse. This is where most of the real harm happens.**

**Option Two: you treat it like a scientist treats unexpected data. 'Interesting. That happened. What was the trigger? What state was I in? What did I tell myself? What can I learn?' No catastrophizing. No minimizing. Just honest data. Then you get back up. And you press play on Day 24\.**

I fell a lot on my way to where I am. Not just once. Not just twice. Many times. The reason I'm here is not that I fell less than other people. It's that every time I got up a little faster.

| ✏ | WORKBOOK: If you've fallen, write about it without judgment — what happened, what you learned, what support you need. If you haven't fallen, write about a fall from your past and what you wish you'd known then. |
| :---: | :---- |

| DAY 24 Accountability: Why You Can't Do This Alone ⏱ 8 minutes   *🎭 Counter-cultural, honest, community-forward* |
| :---- |

I want to say something that goes against the culture we live in. You cannot do this alone. Not because you're weak. Because you're human.

Humans are not wired for isolation. We are social mammals whose nervous systems literally regulate through proximity to other regulated humans.

The most well-documented predictor of sustained transformation isn't discipline, or willpower, or even the quality of the program. It's connection. Community. Having people who know your story and show up anyway.

The years I tried to change in secret — white-knuckling it alone, not telling anyone what I was working on — those were the years I relapsed the most. Not because I was trying less hard. Because I was trying alone.

The years I was in community — in meetings, in therapy, in a men's group — those were the years I actually changed.

Accountability doesn't mean someone watching you and judging you. Accountability means someone who knows your real struggle and checks in on you. Someone you have to look in the eye and tell the truth to. It changes the equation. The behavior you were willing to do in secret becomes harder to do when someone else knows.

| ✏ | WORKBOOK: Name one person in your life you could be more honest with about this work. And if you don't have that person — consider that finding them might be the most important action you take after this program. |
| :---: | :---- |

| DAY 25 Somatic Practices: Releasing What Words Can't Reach ⏱ 9 minutes   *🎭 Body-forward, practical, slightly challenging* |
| :---- |

Twenty-five days in and I want to go deeper into the body. Because some of what drives your patterns is stored below the level of language. Below the level of insight. Below anything you can think or talk or journal your way through.

Trauma — any experience that overwhelmed your system's ability to process it — gets stored in the body as muscle tension, chronic bracing, shallow breathing, postural collapse, or hypervigilance.

You can understand your patterns completely at an intellectual level and still be driven by this body-stored material. This is why talk therapy alone often isn't enough. This is why insight alone doesn't create change.

**Practice 1: Body Scan with Release. Lie down. Move your awareness slowly from feet to head. When you find an area of tension, breathe into it specifically. Then, on the exhale, deliberately release it. Don't force it. Just invite it.**

**Practice 2: Shaking. Stand up. Slightly bend your knees. Begin to bounce gently. Let the bounce become a shake. Let your whole body shake for two to three minutes. This is TRE — Tension and Trauma Releasing Exercises. Animals do this naturally after a threat. We've been socialized out of it. It works.**

**Practice 3: Vocalization. A long, low hum on the exhale activates the vagus nerve. A sigh released audibly does the same. Your nervous system responds to experience, not information.**

| ✏ | WORKBOOK: Choose one of these practices and actually do it today. Not think about doing it. Do it. Then record what you noticed in your body. |
| :---: | :---- |

| DAY 26 Meaning: The Deepest Regulator of All ⏱ 9 minutes   *🎭 Philosophical, personal, deeply human* |
| :---- |

I want to talk about meaning today. Because the deepest regulator of the human nervous system is not a breath technique or a body practice — as important as all of those are. It's meaning.

Viktor Frankl, who survived the Nazi concentration camps and wrote Man's Search for Meaning, said: 'Those who have a why can bear almost any how.'

The seasons of my deepest dysregulation were also the seasons when I had lost my sense of purpose. When the loop was loudest, it was often because nothing felt worth protecting. Nothing felt bigger than the pull of the behavior.

When I found my why — my kids, this work, the specific knowledge that my story could help someone else — everything changed. Not instantly. Not magically. But the meaning gave me something to regulate toward, not just something to regulate away from.

You cannot sustain transformation if it's only about stopping something. You need something to be running toward. What is yours? Not the generic answer. Not 'I want to be a better person.' What is specific, real, and yours?

Maybe it's a version of yourself your children will recognize as present. Maybe it's building something that outlasts you. Maybe it's a relationship you almost lost. Whatever it is — that's the fuel.

| ✏ | WORKBOOK: Write your why in one paragraph. First person. Personal enough that it makes you feel something when you read it. Then read it tomorrow morning when you wake up. |
| :---: | :---- |

| DAY 27 Protecting Your Regulated Self: Boundaries as Biology ⏱ 8 minutes   *🎭 Direct, practical, reframing boundaries as science* |
| :---- |

Let's talk about boundaries. Not as a psychological concept. As biology.

A boundary is anything that protects your nervous system's ability to stay regulated. That's it. That's the whole definition.

The reason most people struggle with boundaries isn't that they don't understand the concept. It's that their nervous system learned early that having needs was dangerous. That saying no created conflict. That taking up space caused the relationship to rupture.

So they learned to be small. Agreeable. Available. To say yes when they meant no, to absorb what they should redirect, to manage other people's nervous systems at the expense of their own.

Every time you violate a boundary you know you need — every time you say yes to something that creates resentment, every time you stay in an environment that dysregulates you — your nervous system pays the cost. It goes into survival mode. And survival mode looks for relief.

So boundaries aren't a soft skill or a nice-to-have. They're a nervous system requirement. Your discomfort around saying no is data. It tells you exactly where your system learned it wasn't safe to have needs.

| ✏ | WORKBOOK: Name one area of your life where you consistently violate a boundary you know you need. What do you gain from keeping it? What does it cost you? What one boundary, if drawn this week, would genuinely protect your regulation? |
| :---: | :---- |

| DAY 28 Helping Others: The Transformation That Transforms You ⏱ 8 minutes   *🎭 Service-forward, purposeful, full-circle* |
| :---- |

There's a phenomenon that every lasting transformation I've ever witnessed has in common. At some point, the person who was fighting for their own survival becomes the person who reaches back.

They turn around and offer their hand to someone still in the dark. And something profound happens when they do. The transformation that felt fragile becomes solid. The identity that was still forming becomes real.

This isn't altruism for its own sake. This is one of the most powerful regulation and identity-consolidation tools available to you. Twelve-step programs figured this out 80 years ago. Service is built into the structure not just because it helps others — but because it fundamentally changes the person doing the serving.

Neuroscience confirms it. Prosocial behavior activates the same reward circuitry as other pleasurable activities. But it does so without the diminishing returns. The 100th act of genuine service feels as good as the first. The dopamine hit of genuine connection to another person's transformation is durable in a way that compulsive behaviors never are.

So here's the question I want to leave you with today: Who are you going to reach back for? It doesn't have to be formal. It might be one conversation with one person in your life who is where you were three months ago. One honest conversation. One 'I know what that feels like. Here's what helped me.' That's enough. That's everything.

| ✏ | WORKBOOK: Name one person you could reach back for. Write what you would say to them. |
| :---: | :---- |

| DAY 29 The Maintenance Plan: Life After Day 30 ⏱ 9 minutes   *🎭 Practical, honest, future-facing* |
| :---- |

Tomorrow is Day 30\. I want to use today to make sure Day 31 isn't the day everything unravels.

Because here's a pattern I've seen too many times: someone completes a program and feels amazing. And then the structure disappears. The daily prompts stop. And without anything to replace it, the old patterns start filling the space. This is not inevitable. But it requires intention.

Your daily regulation practice. What is the one thing you're going to do every day to maintain regulation? Not a five-part morning routine. One thing. Five to ten minutes. Breathwork, a body scan, a walk, journaling. What is it? When? Where?

Your toolkit on standby. You built a personal regulation toolkit in Week 3\. Where is it? Is it written somewhere you'll find it when you're triggered and can't think clearly?

Your accountability structure. Who knows you're committed to this? Who will you talk to when the loop gets loud again?

Your warning signs. What are the early signals that your regulation is slipping? Not the crisis point — the first signal, the subtle one. Identify it now so you catch it early.

Your why. You wrote it on Day 26\. Read it again today. Know it by heart. Because on the hardest days, you won't have the bandwidth to think about why this matters. You need to already know.

| ✏ | WORKBOOK: Write your complete maintenance plan: daily practice, toolkit location, accountability person, warning signs, and your why. |
| :---: | :---- |

| DAY 30 This Is Who You Are Now ⏱ 9-10 minutes   *🎭 Honoring, powerful, true close* |
| :---- |

Thirty days.

I want to start today by just sitting in that for a moment. Not because 30 days is where the work ends. But because 30 days ago, you were someone who was considering whether to do this. And today you're someone who did. That's not small. That's a different person making a different choice.

I hope you understand, maybe for the first time, that the patterns you've been fighting were never about weakness. They were about a nervous system that was doing its best with what it had.

I hope you've felt the difference between fighting an urge and surfing it. Between reacting from State Two and responding from State One. Between being fused with a thought and watching it pass.

I hope at least once in the last 30 days, you noticed the trigger before it took you. That pause — even a second, even half a second — is the evidence that the new pathway is being built.

The behaviors that have run your life were an expression of an identity that is no longer the whole truth about you. You've been building a new identity — methodically, daily, imperfectly, courageously — for 30 days.

You are someone whose nervous system can be regulated. You are someone who has tools. You are someone who, when the alarm fires, knows it's not an emergency. You are someone who has chosen, repeatedly and in the face of real difficulty, to build something new.

That's who you are now.

The crooked lines of your life — all of them, including the ones you're most ashamed of — they brought you here. To this work. To this decision. To this version of yourself. They weren't mistakes. They were directions.

Keep going. I'm proud of you. I mean that more than I know how to say.

| ✏ | WORKBOOK: Write a letter to the version of yourself who pressed play on Day 1\. What do you want them to know? What would you tell them about what's possible? |
| :---: | :---- |

**30 Scripts. 30 Days. One Rewired Life.**

Shaun Critzer • shauncritzer.com

*All rights reserved. For HeyGen production use only.*