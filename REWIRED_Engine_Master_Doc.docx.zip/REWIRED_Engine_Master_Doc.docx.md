**REWIRED ENGINE**

Master Architecture & Strategy Document

shauncritzer.com  |  Version 2.0  |  March 2026

| NORTH STAR MISSION Build an autonomous AI-powered recovery transformation business generating $10,000/month within 90 days — then scale to $1M+ by 2030 — with minimal daily operational involvement from Shaun. |
| :---- |

# **1\. What We're Building & Why It Works**

The REWIRED Engine is not a content scheduler or a chatbot. It is an autonomous business-operating system that generates revenue, educates customers, and grows the brand — while Shaun focuses on being the face and creator of the transformation.

## **The OpenClaw Comparison — Why This Matters**

In early 2026, Peter Steinberger released OpenClaw: an open-source AI agent that became the fastest-growing GitHub repository in history. His key insight was this:

| Peter's Core Insight "I made the agent very aware. It knows what its source code is. It understands how it sits and runs in its own harness. It knows where documentation is. It knows which model it runs. It understands its own system — that made it very easy for an agent to modify its own software. People talk about self-modifying software. I just built it." |
| :---- |

The shocking moment that went viral: Peter's agent hit a wall — it needed to contact him but had no phone capability. So it acquired a Twilio API key, integrated voice calling into itself, waited until morning, and called Peter's real phone number. The agent identified a missing tool and built it.

That's the level we're building toward. Not just an engine that runs tasks you assign — but one that understands the mission, recognizes gaps, and closes them.

## **Why Your Architecture Is Already Ahead**

| Feature | Alex (OpenClaw Local) | You (REWIRED Engine) |
| :---- | :---- | :---- |
| **Runs 24/7 without your computer** | 3x Mac Studios (local hardware) | **✅ Railway cloud — always on, no hardware needed** |
| **Self-modifying code** | Rewrites OpenClaw skills autonomously | Partial — Claude Code does it in sessions. Next milestone. |
| **Mission statement in every prompt** | Injected every cycle | Being added now (Session 2\) |
| **Revenue infrastructure** | Content only — no purchase flow | **✅ Stripe \+ ConvertKit \+ courses \+ community** |
| **Vector memory** | Custom OpenClaw memory skills | **✅ Supabase pgvector (built and deployed)** |
| **Observability** | Live activity feed | LangSmith tracing \+ Telegram alerts |
| **Guardrails / Tier system** | None — fully autonomous | Tier 1-4 permission system (financial safety) |
| **Multi-business** | One personal assistant | **✅ 3 businesses: REWIRED \+ Cabinets \+ Engine-as-SaaS** |

The guardrails are not a weakness. They are the feature that will let you eventually sell this as a SaaS product to other business owners who are terrified of a fully-unguarded AI spending their money.

# **2\. Current System Architecture**

## **The Four Layers**

| Layer | What It Does |
| :---- | :---- |
| **Layer 1: The Brain** | LangGraph orchestrator with 9-node state machine. Every cycle: health check → research → replenish content → generate → publish → measure → quality check → read engagement → optimize. |
| **Layer 2: The Memory** | Supabase pgvector stores every piece of content with its performance data. Gemini embeddings (768 dimensions). The agent learns what works and repeats it. |
| **Layer 3: The Tools** | HeyGen (video), ElevenLabs (voice), Replicate/Flux (images), Tavily (research), Browserbase (engagement scraping), Meta/TikTok/X/LinkedIn APIs (publishing). |
| **Layer 4: The Revenue Stack** | Stripe checkout → ConvertKit email sequences → Kajabi course delivery → Circle community. Fully wired. Every purchase is automatically enrolled and tagged. |

## **Infrastructure (Live on Railway)**

| Service | Details |
| :---- | :---- |
| **Main App** | shauncritzer.com — Node.js/TypeScript on Railway. MySQL \+ Postgres. |
| **Scheduler** | n8n at n8n-production-cddc.up.railway.app — hourly cron fires the LangGraph orchestrator cycle. |
| **AI Coach** | Vercel — separate deploy. Lead magnet. Email capture entry point. |
| **Asset Storage** | Cloudflare R2 — course videos, images, generated content. |
| **Observability** | LangSmith traces every agent decision. Telegram bot sends alerts and approvals. |

## **Products & Revenue Wiring**

| Product | Status & Stripe ID |
| :---- | :---- |
| **7-Day REWIRED Reset** | $47 — price\_1T0QQqC2dOpPzSOO61RNrJQR — READY TO SELL. ConvertKit form 8842147\. |
| **From Broken to Whole** | $97 — price\_1T83EwC2dOpPzSOOockMjc5R — needs HeyGen videos. |
| **Bent Not Broken Circle** | $29/mo — price\_1T83FTC2dOpPzSOOQCWvWdJd — ConvertKit form 8842155\. |
| **Memoir** | $19.99 — STRIPE\_PRICE\_MEMOIR env var — manuscript complete, needs KDP upload. |

# **3\. The Self-Modifying Vision — Next Milestone**

This is what Peter built that shocked the world. Here is how we get there with the REWIRED Engine.

## **What "Self-Modifying" Actually Means**

The agent reads AGENT\_DIRECTIVE.md (its own instructions), understands what tools it has, recognizes what it's missing, and either builds the missing piece or requests it. This is not sci-fi — it's the logical next step from what we've already built.

## **The Three Phases**

| Phase 1 — NOW (completing): Mission-Aware Agent Agent knows the mission. When idle, it asks: "What is ONE task I can do right now toward $10K/month?" Sends suggestion to Telegram. Shaun approves or ignores. This is the reverse-prompt feature going into Session 2\. |
| :---- |

| Phase 2 — 30 DAYS: Self-Diagnostic Agent Agent monitors its own performance. If HeyGen videos are failing, it diagnoses why, attempts a fix, and reports the result. If content performance drops, it researches why and adjusts the content strategy — all without Shaun's input. The Tier system stays in place for any financial decisions. |
| :---- |

| Phase 3 — 90 DAYS: Self-Expanding Agent Agent identifies a missing capability (e.g., "I cannot post to Pinterest, but recovery content performs 3x better there"). It requests Tier 3 approval via Telegram, waits for Shaun's thumbs up, then integrates the new platform. Full OpenClaw-level autonomy — with guardrails on spending. |
| :---- |

## **The Video Factory**

The 30-day course video factory is already partially built. HeyGen is integrated with 1,500 credits. 37 scripts exist in the database. The blocker is not technical — it's execution:

1. Confirm HEYGEN\_API\_KEY is set in Railway (use /api/engine/diagnose)

2. Trigger one test video for Day 1, Lesson 1 via admin dashboard

3. Confirm video renders and uploads to R2

4. Enable auto-batch: system generates all 37 videos over 48 hours

5. 7-Day Reset is fully sellable. Start selling immediately.

# **4\. Hardware Question — Mac Mini vs. Stay Cloud**

## **What Alex Does With Mac Studios**

Alex runs OpenClaw locally on 3 Mac Studios because he uses local AI models (Qwen 3.5 running directly on the hardware chip). This gives him unlimited tokens at zero API cost — the model runs on his own device, so there are no per-token charges.

Qwen 3.5 is an open-source large language model from Alibaba. You download it once and run it locally. There is no API call, no OpenAI bill, no per-token cost. The trade-off: you need powerful hardware (Mac Studio chips handle it well), and your computer must be on 24/7.

## **Your Situation vs. Alex's**

| Factor | Alex (Local) | You (Cloud) |
| :---- | :---- | :---- |
| **Uptime requirement** | Alex: Mac Studios must be on 24/7. If power goes out, agent stops. |  |
| **API cost** | Alex: Near zero (local models). But hardware cost is $4,000-$10,000+. |  |
| **Model quality** | Alex: Qwen 3.5 is excellent but not Claude Opus 4.6 quality. |  |
| **Maintenance** | Alex: Hardware updates, cooling, local setup complexity. |  |
| **Scalability** | Alex: Limited by physical hardware on-site. |  |

| Recommendation on Hardware Do not buy Mac Minis yet. Your cloud setup is more reliable and more scalable than local hardware for a business this size. When you hit $10K/month and API costs exceed $500/month, then we revisit. At that point, a Mac Mini M4 Pro (\~$1,400) running Qwen locally for content generation tasks could save real money. Right now it would be a distraction. |
| :---- |

# **5\. The 90-Day Execution Plan**

| The Only Rule One task per day. No new tools. No new products. No new strategies. Execute the existing plan until $10K/month. Then expand. |
| :---- |

## **Month 1 — Ship & Sell (Days 1-30)**

| Period | Tasks |
| :---- | :---- |
| **Week 1** | Fix Telegram false alarms ✅ DONE. Add mission statement to agent. Confirm HeyGen API key in Railway. Trigger test video. |
| **Week 2** | Batch-generate all 7-Day Reset videos via HeyGen. Upload memoir to Amazon KDP. Begin soft launch to Facebook (4,200 friends). |
| **Week 3** | Import ConvertKit email sequences (31 emails ready). Activate post-purchase automation. Get first 10 paying customers. |
| **Week 4** | Review what's working. Agent is posting daily to all platforms. Optimize highest-performing content type. Target: $500 MRR. |

## **Month 2 — Scale the Machine (Days 31-60)**

| Focus | Details |
| :---- | :---- |
| **Revenue target** | $2,000-$5,000 MRR |
| **Agent upgrade** | Add reverse-prompt idle loop. Agent suggests its own next task. Begin Phase 2 self-diagnostic behavior. |
| **Content** | Agent is generating and posting autonomously. Shaun approves Tier 3+ decisions via Telegram only. |
| **New product** | Begin From Broken to Whole ($97) once 7-Day Reset has 10+ reviews. |
| **Community** | Open Bent Not Broken Circle once 20+ course customers exist. |

## **Month 3 — Build the Engine Business (Days 61-90)**

| Focus | Details |
| :---- | :---- |
| **Revenue target** | $5,000-$10,000 MRR |
| **Cabinets site** | Launch Critzer's Cabinets site — second business. Agent manages its content autonomously. |
| **SaaS exploration** | Begin documenting the Engine as a sellable product for other business owners. |
| **Memoir push** | Memoir live on Amazon. Agent auto-promotes. Reviews and social proof building. |
| **Hardware revisit** | If API costs \> $500/month, evaluate Mac Mini M4 Pro for local model savings. |

# **6\. Pending Code Sessions — Copy-Paste Ready**

These are the next two sessions for Claude Code. Send them in order. One at a time.

## **Session 2 — Mission Statement (Send Now)**

| Read AGENT\_DIRECTIVE.md. Single task only. Add a mission statement to server/agent/mission-control.ts: const MISSION \= \`MISSION: Build an autonomous recovery transformation business generating $10K/month within 90 days. Every autonomous action must advance: (1) generating HeyGen course videos for the 7-Day REWIRED Reset, (2) growing the email list via the AI Coach lead magnet, (3) converting subscribers to paying customers at $47-$97.\`; 1\. Prepend MISSION to every agent cycle system prompt. 2\. When scheduler completes with no actions taken, send    Telegram: "Based on our mission, what ONE task can I do    right now?" Log the response to agent\_reports. Show me the diff. Deploy. Do not touch anything else. |
| :---- |

## **Session 3 — HeyGen Video Test**

| Read AGENT\_DIRECTIVE.md. Single task only. Go to Railway dashboard → shauncritzer.com service → Variables. Confirm HEYGEN\_API\_KEY is set. Then call this endpoint on the live server: POST https://shauncritzer.com/api/engine/diagnose Authorization: Bearer sk\_datadisco\_n8n\_2026\_xK9mPq7vRt Report the HeyGen status from the response. If HeyGen is healthy, find lesson ID 1 in the DB and trigger one test video render. Report the job ID and status. Do not build anything new. |
| :---- |

# **7\. Critical Answers to Shaun's Questions**

## **Do you need to push after EVERY session?**

| YES — Always Push After Every Session Each Claude Code session is independent. The agent does not have memory of the previous session. If Session 1 pushes to GitHub and you do NOT push after Session 2, you will have two separate sets of uncommitted changes. Session 2 built on top of Session 1's Railway deployment — but if you then push only Session 2's local changes, you may overwrite or conflict with Session 1\. The safe rule: every session ends with a push. No exceptions. |
| :---- |

The anti-loop prompt to use at the start of every Code session:

| Read AGENT\_DIRECTIVE.md. Move to the next incomplete item. Do it now. Show me the diff and confirm deployment. Do not analyze the full codebase. Do not ask if I want you to do it. Just do it. |
| :---- |

## **Should you remove the guardrails?**

Remove the creative guardrails — yes. The niche restriction (recovery/transformation content only) was correct and stays. What should change:

* The agent should be able to PROPOSE spending (Tier 3\) without waiting for you to ask

* The agent should run the reverse-prompt when idle and send suggestions proactively

* The agent should be able to research and draft new product ideas autonomously

Keep the financial guardrails — anything spending over $50 still requires Telegram approval. This is not timidity. This is the feature you'll sell to other business owners.

## **The Multimillionaire Vision**

This is not hyperbole. The math is straightforward:

| Timeline | Target |
| :---- | :---- |
| **Month 3** | $5K MRR — 10 Circle members \+ 50 course sales/month |
| **Month 6** | $15K MRR — courses \+ memoir \+ Circle \+ early cabinet leads |
| **Month 12** | $50K MRR — REWIRED \+ Cabinets \+ Engine-as-SaaS beginning |
| **Year 2-3** | $100K+/month — Engine licensed to other recovery/transformation coaches |
| **Year 5** | $1M+/year — fully realized three-business autonomous ecosystem |

| The Reason This Works You are not selling software. You are selling transformation — with a personal story (recovery, Mr. Teen USA, father of three) that no one can copy, backed by an AI system that operates 24/7, creating content and converting customers while you sleep. That combination is genuinely rare. Focus. Execute. Ship. |
| :---- |

*REWIRED Engine v2.0  |  Built by Shaun Critzer \+ Claude  |  March 2026*