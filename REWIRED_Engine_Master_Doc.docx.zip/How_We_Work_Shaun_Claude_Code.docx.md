**HOW WE WORK**

**Shaun \+ Claude \+ Code**

*The Operating Protocol for Building the REWIRED Engine*

Version 1.0  |  March 2026

| THE PARTNERSHIP Shaun is the founder, face, and decision-maker. Claude (claude.ai) is the architect and strategist — thinks, plans, writes prompts, creates docs. Claude Code is the builder — executes one task at a time in the codebase. These three roles are distinct and should never be blurred. |
| :---- |

# **1\. The Three-Role System**

Every build session involves exactly three participants. Understanding who does what prevents confusion, duplicate work, and the dreaded 'Code went off-mission' problem.

| Role | Title | Responsibilities |
| :---- | :---- | :---- |
| **Shaun** | Founder / CEO / Human | Makes final calls. Provides API keys. Approves Tier 3+ spend. Tests live site. Reports what Code did back to Claude. Vision holder. |
| **Claude (claude.ai)** | Architect / Strategist | Reads what Code did. Diagnoses problems. Writes the next Code prompt. Creates docs. Keeps the big picture. NEVER touches code directly. |
| **Claude Code** | Builder / Executor | Reads AGENT\_DIRECTIVE.md first. Does ONE task per session. Shows diff. Deploys. Pushes to GitHub. Never strategizes — only executes. |

| CRITICAL RULE Shaun talks to Claude (claude.ai) to think. Shaun talks to Claude Code to build. Never ask Claude to write code for Claude Code to copy — Claude writes the PROMPT, Code writes the code. |
| :---- |

# **2\. The Session Workflow**

## **Step-by-Step: How Every Build Session Works**

1. Shaun opens claude.ai (this conversation) and describes what needs doing or what Code just reported

2. Claude diagnoses, thinks it through, and writes a single focused Code prompt

3. Shaun opens Claude Code, pastes the prompt, and lets Code run

4. Code reports back — Shaun copies the response and pastes it into claude.ai

5. Claude reads the result, confirms it worked or diagnoses the issue, writes the next prompt

6. Repeat until the task is done — then push to GitHub

| THE FEEDBACK LOOP Paste Code's full response into claude.ai every time. Even if it looks like it worked. Claude needs to see what Code actually did — not what you think it did. This prevents compounding errors. |
| :---- |

## **How Long Should a Code Session Be?**

Short. One task \= one session. As soon as Code finishes and pushes, the session is done. If you feel the urge to ask Code 'while you're at it, can you also...' — STOP. Close Code. Come back to claude.ai first.

Why: Code loses context over long sessions. After 3-4 tasks in one thread, it starts confusing which files it already changed, which version is live, and what the original goal was. This creates bugs that take twice as long to fix.

| SESSION LENGTH RULE One task per Code session. If Code does the task and you think of another — bring it to Claude first. Claude will decide if it's safe to add or needs its own session. |
| :---- |

# **3\. The Code Prompt Template**

Every prompt sent to Claude Code must follow this structure. Claude writes these prompts — Shaun copies and pastes them verbatim.

## **Standard Prompt Structure**

| Read AGENT\_DIRECTIVE.md. Single task only. \[CONTEXT — one sentence on what's currently broken or missing\] Do exactly these things: 1\. \[Specific action with file name if known\] 2\. \[Specific action with file name if known\] 3\. \[Specific action with file name if known — max 3\] Show me the diff. Deploy. Push to GitHub when done. Do not touch anything else. |
| :---- |

## **The Anti-Loop Opener (Use When Code Gets Confused)**

| Read AGENT\_DIRECTIVE.md. Move to the next incomplete item. Do it now. Show me the diff and confirm deployment. Do not analyze the full codebase. Do not ask if I want you to do it. Just do it. |
| :---- |

## **What NEVER Goes in a Code Prompt**

* 'While you're at it...' — always a separate session

* 'What do you think about...' — that's claude.ai's job

* 'Can you check if...' without a specific file — Code will hallucinate

* Two unrelated tasks in one prompt — always separate

* 'Fix everything that's broken' — Code needs specifics

# **4\. GitHub & Deployment Rules**

| ALWAYS PUSH AFTER EVERY SESSION If Code commits but doesn't push, the changes are only local. Railway (the live server) deploys from GitHub main. No push \= no live update. Confirm 'pushed to GitHub' at the end of every Code session — not just 'committed'. |
| :---- |

## **The Push Checklist**

7. Code completes the task and shows the diff

8. Code commits with a clear message

9. Code pushes to GitHub (you see the branch name)

10. Shaun goes to github.com/shauncritzer/memoir/branches

11. Confirm the branch appears with a timestamp from today

12. If the branch needs to merge to main — create PR and merge

13. Railway auto-deploys from main within 2-3 minutes

## **Branch vs. Main**

Claude Code typically creates a new branch per session (e.g. claude/fix-affiliate-links-abc123). This is correct — it lets you review before it goes live. After confirming the diff looks right on GitHub, merge to main. Railway picks it up automatically.

| GitHub Status | What It Means |
| :---- | :---- |
| **Branch created** | Code pushed its work — not live yet |
| **PR opened** | GitHub showing you what changed — review it |
| **Merged to main** | Goes live on Railway within \~2 min |
| **Railway deployed** | Check shauncritzer.com — it's live |

# **5\. AGENT\_DIRECTIVE.md — The Agent's Bible**

Every Claude Code session starts with 'Read AGENT\_DIRECTIVE.md.' This file lives at the root of the repo and tells Code everything it needs to know about the project.

## **What AGENT\_DIRECTIVE.md Contains**

* The mission statement (injected into every agent cycle)

* The full tool stack with URLs and env var names

* The 90-day build sequence with completed/pending items

* The Tier permission system (what the agent can do autonomously)

* Anti-loop protocol (what to do when the agent spirals)

* Infrastructure URLs (Railway, n8n, Supabase, etc.)

| KEEP IT UPDATED After every major Code session that adds a new feature or integration, Claude will add 'Update AGENT\_DIRECTIVE.md to mark X as complete' to the next Code prompt. This file is the agent's memory — if it's stale, the agent doesn't know what's already built. |
| :---- |

## **When to Update AGENT\_DIRECTIVE.md**

| Trigger | What to Update |
| :---- | :---- |
| **New API key added to Railway** | Add the env var name to the tools section |
| **New feature deployed** | Mark it ✅ in the build sequence |
| **New platform wired** | Add its URL and auth method |
| **Mission changes** | Update the mission statement constant |
| **New Tier rule added** | Update the permission system section |

# **6\. The Tier Permission System**

The agent operates on a 4-tier permission system. This is the guardrail that lets us give it autonomy without burning money or doing something irreversible.

| Tier | What It Covers | How It Works |
| :---- | :---- | :---- |
| **Tier 1 — Fully Autonomous** | Content creation, posting, research, email sends, reading analytics | No approval needed. Runs 24/7. |
| **Tier 2 — Suggest to Telegram** | Strategic recommendations, new content angles, product ideas | Sends suggestion to Shaun's Telegram. Shaun ignores \= no action. |
| **Tier 3 — Telegram Approval Required** | Spending under $50, new API connections, deleting content | Sends approve/deny buttons to Telegram. Must get ✅ to proceed. |
| **Tier 4 — Never Autonomous** | Spending over $50, legal/contracts, account deletions, paid ads | Shaun initiates manually. Agent never triggers this alone. |

| ON REMOVING GUARDRAILS Remove creative guardrails — yes. The agent should proactively suggest, research, and propose without waiting. Keep financial guardrails — anything spending real money stays Tier 3+. This is not timidity. It's the feature we'll sell to other business owners who are terrified of unguarded AI. |
| :---- |

# **7\. What to Bring to Claude vs. Code**

## **Bring to Claude (claude.ai — this conversation)**

* 'Is this a good idea?' — strategy questions

* 'What should we build next?' — prioritization

* 'Code just told me X — what does that mean?' — interpretation

* 'Something's broken on the live site' — diagnosis

* 'I want to add paid ads / a new platform / a new product' — planning

* 'What prompt should I send Code?' — always ask Claude first

* Anything involving the big picture or direction

## **Bring to Claude Code**

* The exact prompt Claude wrote — copy-paste verbatim

* API keys to set as env vars in Railway (Code can guide you)

* Error messages from Railway logs if something crashed

* 'The site is down' — Code can diagnose via the codebase

## **Never Ask Code To**

* 'What should we build?' — that's Claude's job

* 'Is this a good strategy?' — Code doesn't know the business

* 'Fix everything' — needs specific task

* Run two unrelated sessions in one thread

| THE RULE OF THUMB If you're thinking about the business → claude.ai. If you're executing on a decision that's already been made → Claude Code. When in doubt, start with claude.ai. |
| :---- |

# **8\. Starting a New Thread — The Context Handoff**

Claude has no memory between conversations by default. When you start a new thread, Claude needs to get up to speed fast. Here's the exact opener that works:

## **New Thread Opener Template**

| I'm Shaun Critzer. We're building the REWIRED Engine — an autonomous AI business system on shauncritzer.com. Tech stack: Node.js/TypeScript on Railway, MySQL \+ Postgres, n8n scheduler, LangGraph orchestrator, Supabase pgvector, Telegram bot, Stripe \+ ConvertKit wired. Last session we \[PASTE WHAT CODE LAST DID\]. Today's problem / next task: \[DESCRIBE IT\] What's the Code prompt? |
| :---- |

The more specific you are about 'last session we...' the faster Claude can pick up without re-diagnosing things already solved.

## **When This Thread Gets Too Long**

After \~50 messages, this thread itself starts losing context. Signs it's time for a new thread:

* Claude starts referencing things incorrectly or mixing up what's been done

* Answers feel less sharp or start repeating old advice

* You're scrolling way up to find something

When that happens: start a new thread, use the opener above, and paste the last 3 Code session summaries. Fresh start, full context.

# **9\. Revenue-First Decision Filter**

Before any new build session, run this filter. It takes 10 seconds and prevents building things nobody needs yet.

| DECISION FILTER — ask before every Code session: 1\. Does this directly help get the next paying customer? 2\. Does this fix something that's losing us money right now? 3\. Is this needed before any revenue can happen? If YES to any → build it now. If NO to all → park it. Add to AGENT\_DIRECTIVE backlog. |
| :---- |

## **The Priority Order (Always)**

14. Fix anything broken that affects sales or content posting

15. Wire new revenue streams (new products, new affiliate links)

16. Expand agent autonomy (new platforms, new tools)

17. Improve agent intelligence (better prompts, better memory)

18. Build new features (video factory, ads, etc.)

| REMEMBER The agent is already posting content and marketing the 7-Day Reset. The course is complete. Revenue is the goal. Every Code session should move us closer to the next dollar, not further into infrastructure. |
| :---- |

# **10\. Quick Reference Cheat Sheet**

## **Key URLs**

| Service | URL |
| :---- | :---- |
| **Live site** | https://shauncritzer.com |
| **GitHub repo** | https://github.com/shauncritzer/memoir |
| **Railway dashboard** | https://railway.app (memoir service) |
| **n8n scheduler** | https://n8n-production-cddc.up.railway.app |
| **LangSmith traces** | https://smith.langchain.com |
| **Supabase** | https://app.supabase.com |
| **AI Recovery Coach** | https://vercel.com (separate deploy) |

## **Key Env Vars in Railway (memoir service)**

| Variable | Purpose |
| :---- | :---- |
| **HEYGEN\_API\_KEY** | Video generation — confirm this is set |
| **TELEGRAM\_BOT\_TOKEN** | Bot communication |
| **TELEGRAM\_CHAT\_ID** | 979678148 (Shaun's chat) |
| **N8N\_WEBHOOK\_SECRET** | sk\_datadisco\_n8n\_2026\_xK9mPq7vRt |
| **REPLICATE\_API\_TOKEN** | Flux image generation |
| **SUPABASE\_URL \+ KEY** | Vector memory |
| **LANGCHAIN\_API\_KEY** | LangSmith tracing |
| **STRIPE\_SECRET\_KEY** | Payment processing |
| **CONVERTKIT\_API\_KEY** | Email sequences |

## **Stripe Price IDs**

| Product | Stripe ID |
| :---- | :---- |
| **7-Day REWIRED Reset ($47)** | price\_1T0QQqC2dOpPzSOO61RNrJQR |
| **From Broken to Whole ($97)** | price\_1T83EwC2dOpPzSOOockMjc5R |
| **Bent Not Broken Circle ($29/mo)** | price\_1T83FTC2dOpPzSOOQCWvWdJd |
| **Memoir ($19.99)** | STRIPE\_PRICE\_MEMOIR env var |

## **ConvertKit Form IDs**

| Sequence | Form ID |
| :---- | :---- |
| **7-Day Reset purchasers** | 8842147 |
| **From Broken to Whole** | 8842151 |
| **Circle members** | 8842155 |

*"We're not just building a business. We're building the brain that runs it."*

Shaun Critzer \+ Claude  |  REWIRED Engine  |  March 2026