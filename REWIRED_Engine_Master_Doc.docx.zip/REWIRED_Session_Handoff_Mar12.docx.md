  **REWIRED ENGINE — SESSION HANDOFF**  

  March 12, 2026 | Start here tomorrow  

## **WHAT WE ACCOMPLISHED TONIGHT**

* **Fixed the 71% pipeline failure rate — ROOT CAUSE IDENTIFIED AND FIXED**

* Switched LLM from Google Gemini free tier (20 req/day) to Claude Haiku API

* ANTHROPIC\_API\_KEY added to Railway and deployed

* @anthropic-ai/sdk installed, llm.ts updated — Claude is now Priority 2 in chain

* All 12 agent consumers (mission-control, orchestrator, content-generator, etc.) now use Claude automatically

* New admin endpoint built: POST /api/admin/test-heygen (authenticated)

## **SYSTEM STATUS RIGHT NOW**

| Component | Status | Notes |
| :---- | :---: | :---- |
| **LLM Brain** | **DONE** | Claude Haiku — Priority 2 (after Forge, before Gemini). $14.91 credit remaining. |
| **Railway Deployment** | **DONE** | Auto-deploys from GitHub main. Latest: Claude LLM switch merged. |
| **Telegram Alerts** | **DONE** | Sends critical alerts. 2hr dedup working. Now reporting correctly. |
| **Self-Monitor (30min)** | **DONE** | Health checks every 30min. Alerts fire correctly. |
| **Engagement Reader (12hr)** | **DONE** | Browserbase scrapes real engagement. Storing to vector memory. |
| **Mission Control** | **DONE** | Mission statement injected. Zero-action nudge wired. |
| **Facebook Posting** | **DONE** | Meta API connected. Posts going out. |
| **Affiliate Links** | **DONE** | 5 active links with real URLs. Wrong-audience offers paused. |
| **HeyGen Videos** | **NEVER CALLED** | API key confirmed. $25 credit. 37 scripts in DB. ZERO videos triggered. |
| **ConvertKit Sequences** | **NEVER CALLED** | 31 emails written. NOT imported into ConvertKit yet. Manual task. |
| **YouTube** | **NEVER CALLED** | OAuth in Production mode. Token may be expired. Not tested. |
| **LinkedIn** | **NEVER CALLED** | Code ready. Env vars not set in Railway. |
| **AI Recovery Coach** | **DONE** | Running on Vercel separately. Lead capture working. |
| **Memoir on Amazon** | **NOT STARTED** | Manuscript complete. Not uploaded to KDP. |

## **API CREDITS SNAPSHOT**

| Service | Balance | Limit | Notes |
| :---- | :---- | :---- | :---- |
| Claude API (Anthropic) | $14.91 remaining | \~$15 grant | Primary LLM now. Haiku model. Will last months. |
| HeyGen | $25.00 remaining | $25 loaded | NEVER USED. Next task \= trigger first video. |
| OpenAI | $0.72 spent/$120 budget | $120/mo cap | DALL-E images only. Flux should replace this. |
| Google Gemini | Free tier | 20 req/DAY | Was causing 71% failures. Now fallback only. |
| ElevenLabs | Unknown | Paid plan | Voice generation. Check balance. |

## **TOMORROW — ONE TASK ONLY**

  **TRIGGER THE FIRST HEYGEN VIDEO**  

HeyGen has $25 sitting idle. 37 scripts are in the database. The webhook is verified. The API key is in Railway. This has NEVER been called once. Tomorrow we fix that.

**Step 1 — Hit the new test endpoint:**

Open PowerShell and run:

curl \-X POST https://shauncritzer.com/api/admin/test-heygen \-H "Content-Type: application/json" \-H "Authorization: Bearer YOUR\_N8N\_WEBHOOK\_SECRET"

Replace YOUR\_N8N\_WEBHOOK\_SECRET with: sk\_datadisco\_n8n\_2026\_xK9mPq7vRt

**Step 2 — If that fails, send this to Claude Code:**

Read AGENT\_DIRECTIVE.md. Single task only.

Test the HeyGen video pipeline. HEYGEN\_API\_KEY and HEYGEN\_AVATAR\_ID are

confirmed in Railway. The webhook https://shauncritzer.com/api/heygen/webhook

is verified in HeyGen dashboard.

1\. Query course\_lessons WHERE sort\_order \= 1, show me title \+ script

2\. Call the HeyGen API to create ONE test video (test mode \= watermarked)

3\. Return the HeyGen job ID

Do not build anything new. Just query DB and trigger. Push to GitHub.

## **AFTER HEYGEN WORKS — IN ORDER**

* **1\. Import ConvertKit sequences (manual — 31 emails already written, just need upload)**

* 2\. Credit monitoring dashboard — one view showing all API balances with low-credit Telegram alerts

* 3\. Two-way Telegram — send commands, agent executes them

* 4\. LinkedIn env vars in Railway

* 5\. YouTube token refresh

* 6\. Memoir on Amazon KDP

* 7\. Critzer's Cabinets site (Month 2-3)

## **HOW WE WORK — QUICK RULES**

* Claude.ai \= think/plan/write prompts. Claude Code \= execute only.

* ONE task per Code session. Never 'while you're at it.'

* Always paste Code's full response back into Claude.ai.

* Every session ends with push to GitHub. Commit is NOT push.

* Code creates branches. Merge to main. Railway auto-deploys in \~2 min.

* New thread opener: 'I'm Shaun Critzer. We're building the REWIRED Engine... Last session: \[X\]. Today: \[Y\]. What's the Code prompt?'

## **ARCHITECTURE SNAPSHOT**

* Live site: https://shauncritzer.com

* GitHub: https://github.com/shauncritzer/memoir

* Railway: memoir service — auto-deploys from main branch

* n8n: https://n8n-production-cddc.up.railway.app — hourly cron POST /api/scheduler/run

* AI Recovery Coach: Vercel (separate app — leave it alone)

* LangSmith: https://smith.langchain.com — check here to watch agent traces

* 

* Boot sequence: 0s Scheduler+MissionControl | 60s SelfMonitor | 90s EngagementReader

* LLM chain: Forge → Claude Haiku → Gemini (fallback) → OpenAI (fallback)

* Products: 7-Day Reset $47 | From Broken to Whole $97 | Circle $29/mo | Memoir $19.99

## **ANTI-LOOP PROTOCOL**

**If Code starts analyzing instead of building, paste this:**

Read AGENT\_DIRECTIVE.md. Move to the next incomplete item. Do it now.

Show me the diff and confirm deployment. Do not analyze the full codebase.

Do not ask if I want you to do it. Just do it.

**You're day 6 porn-free. The engine is running. Sleep well.**