**THE REWIRED ENGINE**

Master Operating Manual

*Vision • Architecture • Current State • Roadmap • SaaS Blueprint*

Shaun Critzer • March 2026 • CONFIDENTIAL

# **PART 1: THE VISION**

**This is not a content scheduling tool. This is not a social media manager. This is not a chatbot.**

The REWIRED Engine is an autonomous AI business operating system — a living system that thinks, creates, heals itself, learns from results, and grows a transformation brand without requiring constant human input. It is the first of its kind built specifically for the recovery and nervous system transformation space.

The long-term vision has three phases:

## **Phase 1: The Brand Engine (Now)**

An autonomous system that runs the Shaun Critzer brand — posting content, generating course videos, nurturing email subscribers, tracking revenue, and briefing Shaun every 30 minutes on what it has done and what it needs.

## **Phase 2: The Productized Engine (6-12 Months)**

The Engine becomes a SaaS product — sold to coaches, therapists, and transformation practitioners who want the same autonomous brand-building capability without needing to understand the technology underneath.

## **Phase 3: The REWIRED Franchise (12-24 Months)**

Every coach who completes REWIRED Certification gets their own Engine instance — their own AI that posts their content, generates their course videos in their voice, nurtures their list, and certifies their students. Shaun becomes the franchisor of nervous system transformation.

# **PART 2: THE NORTH STAR — What Mind-Blowing Looks Like**

This section captures the full vision of what the REWIRED course experience becomes when the Engine is fully built. This is not fantasy — every element described here is technically achievable with the stack we are already building.

## **A Living Course That Knows You**

Someone buys the 30-Day REWIRED Reset. Day 1 they receive a video — but it is not Shaun talking to a static camera. The video opens with Shaun's avatar in a calm, warmly lit room. He speaks directly to camera. Then the frame shifts — real neuroscience visualizations animate behind him showing exactly what happens in the brain during compulsive loops. Not stock footage. Custom-generated graphics that make the invisible visible.

Midway through each lesson, the course pauses and asks one question. Based on the answer, the next day's content subtly shifts. Someone who identifies as an avoider gets different framing than someone who identifies as a controller. Same Shaun. Same methodology. Personalized delivery.

## **The AI Recovery Coach Integration**

The free AI Recovery Coach captures behavioral patterns over 7 days before someone buys. By the time they purchase, the course already knows their trigger profile. Day 1 video references things specific to them — not by name, but by nervous system type. The course feels like it was built for them, because it was.

## **The Community Layer**

Inside the Circle community, every Friday Shaun's avatar hosts a live-style recap — generated from that week's actual community conversations. Real questions members asked, answered in video format. Automated. Personalized to the week. Members feel seen without Shaun manually engaging every post.

## **The Memoir Becomes Interactive**

Chapters of Crooked Lines: Bent, Not Broken release alongside course modules. Read the chapter, watch Shaun process that moment live on video, then complete the workbook exercise that connects his story to yours. The memoir is not a standalone product — it is the emotional backbone of the entire curriculum.

## **The Certification Path**

30 days becomes 90 days becomes REWIRED Coach Certification. People who have completed their own transformation learn to guide others. The Engine tracks their progress, generates their practice materials, issues completion certificates. Certified coaches become brand ambassadors and affiliate partners.

## **The Video Production Vision**

Each course lesson combines three visual layers in sequence:

* Shaun's avatar speaking directly — personal, warm, credible

* Neuroscience animations — making the invisible visible (dopamine loops, nervous system states, trauma storage)

* Cinematic b-roll — AI-generated imagery that matches the emotional tone of the script

* Slideshow callouts — key concepts reinforced visually mid-lesson

* Workbook bridges — video pauses and directs to specific workbook exercises

This is what separates REWIRED from every other recovery course on the market. Most courses are a talking head. REWIRED is a cinematic nervous system experience.

# **PART 3: CURRENT ARCHITECTURE**

The Engine is live and running on Railway. Here is the full current state as of March 2026\.

## **Infrastructure**

* Hosting: Railway (Node.js/TypeScript, auto-deploys from GitHub)

* Database: MySQL (Railway) \+ PostgreSQL (n8n)

* Domain: shauncritzer.com

* GitHub: github.com/shauncritzer/memoir

* Scheduler: n8n at n8n-production-cddc.up.railway.app

* Admin Panel: shauncritzer.com/admin/mission-control

## **AI Stack**

* Primary LLM: Claude Haiku 4.5 (Anthropic) — content generation, briefings, strategy

* Fallback LLM: Google Gemini (free tier) — rate limit fallback only

* Avatar Video: HeyGen (Shaun 2026 custom avatar, 1500 credits)

* Voice Clone: ElevenLabs (Shaun Critzer voice, ID: I0ed8NMMF80zi7lbbJyI)

* Image Generation: Flux 1.1 Pro (Replicate) with DALL-E fallback

* Web Research: Tavily API

* Browser Automation: Browserbase

* Observability: LangSmith (langchain tracing)

## **Active Autonomous Systems**

| Component | Status | Notes |
| :---- | :---- | :---- |
| Content Generator | **LIVE** | Creates posts every 60 min for all platforms |
| Post Scheduler | **LIVE** | Publishes every 10 min, 3x/day per platform |
| Mission Control | **LIVE** | 30-min agent cycle, Telegram briefings |
| Self-Monitor | **LIVE** | Health checks, rate limit detection |
| Self-Heal | **LIVE** | Auto-throttles failed platforms |
| Engagement Reader | **LIVE** | 12-hr reads, feeds vector memory |
| Niche Expander | **LIVE** | Discovers content angles autonomously |
| Strategy Brain | **LIVE** | Updates content strategy from data |
| Vector Memory | **LIVE** | Learns from performance over time |
| HeyGen Pipeline | **PARTIAL** | Voice fixed, table routing fixed — testing |
| ConvertKit Integration | **LIVE** | Auto-tags \+ sequences on purchase |
| Stripe Webhooks | **LIVE** | Purchase events trigger email automation |
| Instagram Posting | **LIVE** | @shauncritzer.rewired |
| Facebook Posting | **LIVE** | Rate limit clears Mar 13 |
| X/Twitter Posting | **LIVE** | Active |
| LinkedIn Posting | **PARTIAL** | Generated, not confirmed posting |
| YouTube Posting | **PARTIAL** | HeyGen dependency — in progress |
| Two-Way Telegram | **PLANNED** | Gap 1 — next build session |
| Autonomous Email | **PLANNED** | Gap 2 — agent drafts, Shaun approves |
| Meta Token Refresh | **PLANNED** | Gap 4 — auto-renewal system |
| Approval Dashboard | **PARTIAL** | Individual buttons work, summary broken |

## **Products & Revenue**

* 7-Day REWIRED Reset: $47 — price\_1T0QQqC2dOpPzSOO61RNrJQR — LIVE

* From Broken to Whole: $97 — price\_1T83EwC2dOpPzSOOockMjc5R — LIVE

* Bent Not Broken Circle: $29/mo — price\_1T83FTC2dOpPzSOOQCWvWdJd — LIVE

* Memoir (Crooked Lines): $19.99 — LIVE

* Current Revenue: $235/month from 5 purchases

* 90-Day Target: $10,000/month

## **ConvertKit Sequences**

* 7-Day Reset sequence: ID 2577789

* From Broken to Whole sequence: Active

* Circle membership sequence: Active

* 31 emails across 7 sequences imported

* Week 1 sequence: Fully written and live

# **PART 4: THE 5 GAPS — What Separates Us From Full Autonomy**

These are the five capabilities the Engine does not yet have that would make it fully autonomous. They are listed in build priority order.

## **Gap 1: Two-Way Telegram**

Current state: Telegram receives briefings and notifications. You cannot send commands back.

Future state: You send a message like 'post that Facebook draft now' or 'pause Instagram for 48 hours' and the agent executes it.

Why it matters: This is the difference between monitoring and controlling. Right now the Engine reports to you. After this, you can direct it.

## **Gap 2: Autonomous Email Writing**

Current state: ConvertKit sequences were manually written and imported. The agent cannot write new emails.

Future state: The agent drafts new email sequences based on content performance, sends them to Telegram for approval, and loads them into ConvertKit automatically.

Why it matters: Email is the highest-converting channel. 6 subscribers at $235/month means each subscriber is worth $39. Automation that grows and nurtures this list is the fastest path to $10K.

## **Gap 3: LinkedIn and YouTube Confirmed**

Current state: Content is generated for both platforms. Actual posting is unconfirmed.

Future state: Both platforms confirmed live with engagement tracking.

## **Gap 4: Meta Token Auto-Refresh**

Current state: Facebook/Instagram tokens expire and require manual renewal via Meta developer dashboard.

Future state: The Engine detects token expiry 7 days in advance, generates a refresh link, sends it to Telegram, and updates the token automatically after approval.

## **Gap 5: Approval Dashboard Fix**

Current state: Individual Yes/No buttons work in Mission Control. The 'View X Pending Approvals' Telegram button does not open the correct view.

Future state: Telegram approval buttons work end-to-end, enabling full remote management from mobile.

# **PART 5: THE SAAS BLUEPRINT**

The Engine is not just Shaun's business tool. It is a product. Here is how it gets packaged and sold to other coaches and transformation practitioners.

## **The Core Insight: Legendary Marketer Principle**

The best SaaS onboarding does not teach users how the technology works. It clicks a button and everything is set up for them. David Sharpe's Legendary Marketer did not explain what an autoresponder was — it gave users a link that auto-installed their entire funnel into Aweber.

The REWIRED Engine SaaS works the same way. A coach signs up. They connect their accounts. The Engine sets everything up. They start receiving Telegram briefings within 24 hours.

## **Onboarding Flow**

* Step 1: Create account. Enter niche, name, brand voice in plain English.

* Step 2: Connect via OAuth or MCP: Instagram, Facebook, X, LinkedIn, YouTube.

* Step 3: Connect payment processor (Stripe or PayPal).

* Step 4: Connect email platform (ConvertKit, Mailchimp, or Flodesk).

* Step 5: Upload a 3-minute video for avatar creation OR select from library avatars.

* Step 6: Record or upload 60 seconds of voice for ElevenLabs cloning.

* Step 7: Engine activates. First Telegram briefing arrives within 2 hours.

## **Pricing Tiers**

* Starter — $97/month: Content generation \+ posting, basic analytics, Telegram briefings

* Growth — $197/month: \+ Email automation, HeyGen video generation, approval workflows

* Authority — $397/month: \+ Custom avatar, voice clone, course video production, strategy brain

* Certified — $997/month: \+ REWIRED Coach certification, white-label, affiliate program

## **The Certification Flywheel**

Every REWIRED Certified Coach becomes an affiliate. They earn 30% recurring commission on every client they refer who subscribes to the Engine. They are incentivized to promote the platform. Each certified coach is a distribution channel.

At 100 certified coaches each generating 3 referrals at $197/month: $59,100/month recurring before Shaun touches it.

## **Technology Requirements for SaaS**

* Multi-tenant database architecture (one Engine instance per customer)

* OAuth connection management (Meta, Google, LinkedIn, X)

* Secure credential storage and rotation

* Customer dashboard (Mission Control white-labeled per account)

* Usage metering (HeyGen credits, Claude API calls, ElevenLabs characters)

* Billing integration (Stripe subscriptions)

* Support system (Telegram-first, async)

# **PART 6: BUILD PROTOCOL**

This section documents how the Engine is built so any team member can pick up where another left off.

## **Three-Tool Workflow**

* Claude.ai (this document's home): Architect, strategist, prompt writer. Plans sessions, writes Code prompts, analyzes results.

* Claude Code with Opus: Builder. Executes one task at a time. Always reads AGENT\_DIRECTIVE.md first.

* Railway Agent: Infrastructure changes, environment variables, deployment issues.

## **Session Rules**

* One task per Code session. Never 'while you're at it.'

* Always paste Code's full response back into Claude.ai for analysis.

* Every session ends with push to GitHub. Commit does not equal push.

* Code creates branches. Merge to main. Railway auto-deploys in 2 minutes.

* AGENT\_DIRECTIVE.md is the source of truth. Update it after major changes.

## **Anti-Spiral Protocol**

| STOP | When Shaun asks about local AI models, Apple silicon, OpenClaw, or 20 new features in one message — this is ADHD \+ shiny object syndrome activating. The response is: 'What is the ONE thing blocking revenue right now?' Return to that. |
| :---: | :---- |

## **Priority Order (Always)**

* 1\. Does the system post autonomously? (If no, fix this first.)

* 2\. Does HeyGen produce videos? (Revenue-generating content.)

* 3\. Does email automation fire on purchase? (Conversion.)

* 4\. Is Telegram two-way? (Remote control.)

* 5\. Everything else.

## **The Anti-Build Trap**

Shaun's ADHD creates a predictable pattern: build infrastructure for products that do not exist yet instead of selling the product that does. The Engine is the infrastructure. The 7-Day REWIRED Reset is the product. Until it has 50 paying customers, all energy goes to selling, not building.

| RULE | Never build a new feature before the existing product has 10 paying customers. Revenue first. Infrastructure second. |
| :---: | :---- |

# **PART 7: KEY INFRASTRUCTURE REFERENCE**

Quick reference for critical configuration. Do not share outside the team.

## **Railway Environment**

* Project: harmonious-gentleness

* Service: memoir (shauncritzer.com)

* n8n: n8n-production-cddc.up.railway.app

* Admin Secret: In Railway variables (ADMIN\_SECRET)

* n8n Webhook Secret: sk\_datadisco\_n8n\_2026\_xK9mPq7vRt

## **Platform Accounts**

* Instagram: @shauncritzer.rewired (API connected via passiveaffiliate.ai Meta account)

* Facebook Page: facebook.com/freedomwithshaun

* HeyGen Avatar: Shaun 2026 (casual grey henley, hands together)

* ElevenLabs Voice: Shaun Critzer clone — I0ed8NMMF80zi7lbbJyI

* Telegram Bot: @rewired\_reset\_bot — Chat ID: 979678148

* LangSmith: smith.langchain.com (trace all agent activity)

## **Collaborators**

* Claude Cote: Business partner on Engine SaaS productization

* Michael Der (Digital Gravity, San Francisco): Tech collaborator

* VA Team: Content support and task execution

* Closer (Canada): Sales conversion

# **PART 8: NORTH STAR METRICS**

These are the only numbers that matter. Everything built either moves these or it does not.

* Monthly Recurring Revenue: $235 today → $10,000 target (90 days)

* Email Subscribers: 6 today → 500 target (90 days)

* Course Students: 5 today → 50 target (90 days)

* Daily Autonomous Posts: 0 confirmed today → 10/day target (this week)

* HeyGen Videos Produced: 0 today → 7 (7-Day Reset complete) → 30 (30-Day Reset)

* Telegram Briefings: Running → two-way command capability (this month)

| TRUTH | The Engine is built. The audience is not. Every hour spent on infrastructure instead of audience growth is an hour spent building a louder megaphone in an empty room. Ship. Sell. Then scale. |
| :---: | :---- |

*REWIRED Engine Master Manual • Last Updated March 2026 • Shaun Critzer*