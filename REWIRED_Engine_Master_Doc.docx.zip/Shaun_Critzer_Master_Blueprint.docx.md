

| THE MASTER OPERATIONS BLUEPRINT Shaun Critzer Empire · Built on AI · March 2026 |
| :---: |

| 🎯 MISSION:  Build 3 autonomous AI-powered businesses. Use them as live case studies to sell the engine that runs them to the world. |
| :---- |

| PART 1: THE THREE BUSINESSES |
| :---- |

## **Business 1 — Shaun Critzer Brand (shauncritzer.com)**

Recovery · Fitness · Transformation · Speaking · Digital Products

| Products — LIVE NOW 7-Day REWIRED Reset — $47 ✅ READY TO SELL 30-Day From Broken to Whole — $97 (needs videos) Crooked Lines Memoir — $19.99 (final edits \+ KDP) Bent Not Broken Circle — $29/mo (after 50 course sales) REWIRED Methodology License — $2k-5k (Year 2\) | Revenue Target Month 1-3: $500 → $3,000/mo Month 4-6: $3,000 → $10,000/mo Month 7-12: $10,000 → $25,000/mo What AI Runs All content creation \+ publishing Email nurture sequences Lead capture \+ CTA rotation Course video generation (HeyGen) |
| :---- | :---- |

## **Business 2 — Critzer's Cabinets (critzerscabinets.com)**

40-year family business · Kitchen & Bath · 4,000 sq ft showroom · Virginia

| What Gets Built Premium site redesign AI sales agent (questions → quote → order) 7,000+ product database (1k started) AI CAD room designer Manufacturer API integration Dimension scanning app integration (exists) | Revenue Potential Avg kitchen: $15k-$50k Avg bath: $8k-$20k 3 extra AI-converted jobs/mo \= $45k-$150k Biggest financial opportunity in portfolio Your Role Showroom relationship appointments Field dimension verification Installation coordination |
| :---- | :---- |

## **Business 3 — The Engine (SaaS Product — Name TBD)**

The autonomous business operating system that runs Business 1 and 2\. Sell it to the world.

| What You Sell Done-for-you autonomous business deployment $5k-$15k setup \+ $2k-$5k/mo managed service Self-serve SaaS tiers also available White-label for agencies SaaS Pricing Tiers Starter: $297/mo — content \+ publishing Growth: $697/mo — full agent suite Enterprise: $1,997/mo — custom agents Agency: $4,997/mo — unlimited clients | The Case Study Pitch *"We built this to run a recovery coach's brand and a 40-year cabinet company. Both now run autonomously. Here's the revenue. Want this for your business?"* Revenue Path 10 managed clients \= $20k-$50k/mo 30 managed clients \= $60k-$150k/mo Pure margin, no inventory, no showroom |
| :---- | :---- |

| PART 2: THE TECH STACK — OPTIMAL SETUP |
| :---- |

| ✅ RULE:  Every tool has one job. Don't let tools overlap. Don't add tools to solve problems that are actually code bugs. |
| :---- |

## **The Brain-Eyes-Arms-Ears Framework**

| 🧠 BRAIN — Reasoning Claude API Sonnet — complex tasks, agent decisions, content generation Claude API Haiku — bulk simple tasks (20x cheaper than Sonnet) LangGraph — agent orchestration, coordinates who does what CrewAI — multi-agent workflows for complex sequences 👁 EYES — Research Tavily — web research API, finds trending topics, competitor intel Firecrawl — deep site scraping when Tavily isn't enough | 💪 ARMS — Execution Browserbase — cloud browser automation (already paid) n8n (self-hosted on Railway) — workflow triggers and scheduling Make.com — CANCEL, replaced by n8n 👂 EARS — Feedback LangSmith — agent observability, see every decision and failure Supabase pgvector — agent memory, stores what worked Platform APIs — reads real engagement data back into the loop |
| :---- | :---- |

## **Full Tool Stack — Keep / Replace / Add**

| Status | Tool | Purpose / Note |
| :---- | :---- | :---- |
| **✅ KEEP** | **Railway** | Hosting — handles Node apps well |
| **✅ KEEP** | **Stripe (Live)** | Payments — non-negotiable best in class |
| **✅ KEEP** | **HeyGen (1500cr)** | AI avatar video — no real competitor |
| **✅ KEEP** | **ElevenLabs** | Voice cloning — best in market |
| **✅ KEEP** | **Tavily** | Search API for agents — better than raw Google |
| **✅ KEEP** | **Browserbase** | Cloud browser automation — already paid |
| **✅ KEEP** | **Cloudflare R2** | Media storage — cheap and fast |
| **✅ KEEP** | **ConvertKit** | Email — solid for creator scale |
| **✅ KEEP** | **GitHub** | Repo — both agents have access |
| **🔄 REPLACE** | **Make.com → n8n** | n8n self-hosted on Railway, no per-op pricing |
| **🔄 REPLACE** | **DALL-E → Flux** | Flux via Replicate — better quality, cheaper |
| **🔄 REPLACE** | **Internal cron** | Replace with n8n as external heartbeat |
| **➕ ADD** | **LangGraph** | Agent orchestration backbone — wire now |
| **➕ ADD** | **Supabase pgvector** | Agent memory — free tier, no new vendor |
| **➕ ADD** | **LangSmith** | Observability — see what agents actually do |
| **➕ ADD** | **Ideogram** | Text-in-image for quote graphics (Flux for photos) |
| **🚫 SKIP** | **OpenClaw fork** | Steal the concept, build it clean in your stack |
| **🚫 SKIP** | **n8n paid tier** | Self-host on Railway — free beyond compute cost |

## **AI Model Routing — Cost Optimization**

| 💡 RULE:  Route by complexity. Never use Sonnet for tasks Haiku can do. Never use Haiku for tasks that need Sonnet. |
| :---- |

| Model | Use For | Cost Note |
| :---- | :---- | :---- |
| **Claude Sonnet** | Content generation, agent decisions, complex reasoning | Primary model — use for quality tasks |
| **Claude Haiku** | Bulk formatting, data extraction, simple classification | 20x cheaper than Sonnet — use for volume |
| **Flux (Replicate)** | Lifestyle photos, people, recovery imagery | \~$0.003-0.05/image — no subscription |
| **Ideogram** | Quote graphics, text overlays, branded visuals | Better for text-in-image than Flux |
| **ElevenLabs** | Course narration, podcast audio | Credit-based — already optimized |
| **HeyGen** | Course lesson videos, YouTube avatar content | 1,500 credits — use test mode first |
| **Gemini Flash** | Free-tier overflow for bulk low-stakes tasks | Fallback only — not primary |

| PART 3: YOUR DAILY WORKFLOW — THREE CLAUDES, ONE JOB EACH |
| :---- |

| ⚠️ THE TELEPHONE PROBLEM:  Long conversations degrade. The message changes by the end. Solution: Short focused sessions. One task per session. AGENT\_DIRECTIVE.md holds the strategy so you never re-explain. |
| :---- |

## **The Three Claude Tools — When to Use Each**

|  🗣 Claude.ai (THIS) THE ARCHITECT Think through strategy Diagnose what went wrong Write precise Code briefs Review transcripts \+ screenshots Answer 'should I...' questions Draft AGENT\_DIRECTIVE.md updates Use when: Planning, reviewing, deciding  |  ⚡ Claude Code THE BUILDER Execute one task at a time Fix bugs, build features Read AGENT\_DIRECTIVE.md first Deploy to Railway Run on schedule (new in 2.0) Use when: Building, fixing, deploying *Desktop app → Opus 4.5 model*  |
| ----- | ----- |

|  🖥 Cowork THE EXECUTOR Desktop automation tasks File and folder management Local task execution Things that run on your machine Use when: Local automation, file work  |  🔑 THE GOLDEN RULE:  Plan with Claude.ai → Execute with Code → Automate with Cowork.They are sequential, not competing. Never skip the planning step.  |
| ----- | :---- |

## **How to Run a Claude Code Session — Anti-Loop Protocol**

| ⚠️ THE LOOP PATTERN TO AVOID:  Read codebase → Give long analysis → Ask 'want me to do that?' → You say yes → Read codebase again → Repeat. Never gets built. |
| :---- |

**Follow this exact pattern for every Code session:**

1. **OPEN with the directive:** "Read AGENT\_DIRECTIVE.md."  — nothing else first

2. **STATE the single task:** "Your task is \[item N from directive\]. Do it now."

3. **DEFINE done:** "Show me the diff and confirm it deployed. That's the entire task."

4. **ENFORCE scope:** If it goes broad: "Stop. One task. Back to \[item N\]."

5. **CONFIRM before closing:** Verify the fix actually works before ending the session

6. **UPDATE the directive:** Ask Claude.ai to update AGENT\_DIRECTIVE.md with completed item

| 📌 COPY-PASTE OPENER FOR EVERY CODE SESSION:  "Read AGENT\_DIRECTIVE.md. Move to the next incomplete item. Do it now. Show me the diff and confirm deployment. Do not analyze the full codebase. Do not ask if I want you to do it. Just do it." |
| :---- |

## **Tier Permission System — What Needs Your Approval**

| Tier | Type | Examples | Your Action |
| :---- | :---- | :---- | :---- |
| **Tier 1** | **Auto-Execute** | Post content, send scheduled emails, generate images | Nothing — just happens |
| **Tier 2** | **Execute \+ Notify** | Spend under $25, adjust schedules, update copy | Review in briefing |
| **Tier 3** | **Ask First** | Spend $25-$100, contact customers, new campaigns | YES or NO in Mission Control |
| **Tier 4** | **Must Approve** | Financial over $100, pricing changes, new business | Explicit YES required |
| **🚨 IMPORTANT:**  The Tier 3 niche\_activation approvals you saw (AI/ML niches) — hit NO on both. The agent is scoping work outside your brand. You want recovery/fitness/transformation content only. Update the system prompt to restrict niche research to your verticals. |  |  |  |

| PART 4: THE BUILD SEQUENCE — 90 DAYS TO AUTONOMOUS |
| :---- |

| 🎯 NORTH STAR:  One complete working loop from input to autonomous revenue before adding any new features. Depth before breadth. |
| :---- |

## **Week 1 — Make It Actually Post**

| \[CODE TASK 1\]  Fix Ready → Published scheduler bug Branch pushed. Merge the PR in GitHub. Verify Railway redeploys. Confirm a post flips from Ready to Posted within 2 minutes. STATUS: BRANCH PUSHED, AWAITING MERGE |
| :---- |

| \[CODE TASK 2\]  Install n8n on Railway \+ replace Make.com New Railway service from n8n Docker image. Configure to call /api/scheduler/run every hour. Cancel Make.com subscription after confirmed working. |
| :---- |

| \[CODE TASK 3\]  Fix video module\_id mismatch Batch video generator errors with module\_id=30017 not found. The course\_lessons table module IDs don't match what the video system expects. Map them correctly. Then test HeyGen render on Module 1 test mode. |
| :---- |

| \[YOU TASK\]  Import ConvertKit sequences 31 emails are written. 7 sequences designed. Log into ConvertKit, create sequences, paste emails in. Set up 6 automation rules. This is manual work — AI cannot do it for you through the API at this stage. |
| :---- |

## **Week 2 — Make It Actually Think**

| \[CODE TASK 4\]  Wire LangGraph as orchestration layer Install LangGraph. Create the basic agent graph: Research node (Tavily) → Content node (Claude Sonnet) → Publish node (existing pipeline). Replace the linear cron with this graph. |
| :---- |

| \[CODE TASK 5\]  Add Supabase pgvector for agent memory Enable pgvector on existing Supabase instance. Create embeddings table. Store what content performed well. Feed back into content generation prompts. |
| :---- |

| \[CODE TASK 6\]  Add LangSmith observability LANGSMITH\_API\_KEY in Railway env vars. Wrap all LangGraph calls with LangSmith tracing. Now you can see every agent decision and where things break. |
| :---- |

## **Week 3 — Make It Actually Sell**

| \[LAUNCH\]  7-Day REWIRED Reset goes on sale Stripe is live. Course UI is complete. Scheduler posting. ConvertKit sequences live. This is the moment. Announce it. $47. First sale validates the entire system. |
| :---- |

| \[CODE TASK 7\]  Replace DALL-E with Flux via Replicate Add REPLICATE\_API\_KEY to Railway. Update image generation calls to use Flux Pro model. Better quality, lower cost per image. |
| :---- |

| \[YOU TASK\]  Memoir final edits \+ Amazon KDP setup Final read-through of Crooked Lines. Upload to KDP. Set price at $19.99. Add to site with Stripe checkout option also. Two revenue streams for the book. |
| :---- |

## **Week 4 — Make It Actually Learn**

| \[CODE TASK 8\]  Browserbase engagement feedback loop Browserbase monitors published posts on each platform. Reads actual engagement. Feeds data back to Supabase vector store. Content agent uses this to optimize topics and timing. |
| :---- |

| \[CODE TASK 9\]  Restrict niche research to brand verticals Update Mission Control agent system prompt to limit research to: recovery, sobriety, fitness, transformation, bodybuilding, nervous system regulation, trauma. Prevents rogue AI/ML niche suggestions. |
| :---- |

## **Month 2 — Course Videos \+ Cabinets**

| \[CODE TASK 10\]  Complete 30-Day course video pipeline Fix module\_id mapping. Render Module 1-4 (scripts exist). Auto-generate Module 5-8 scripts. Batch render all 30 days. Course goes live at $97. |
| :---- |

| \[CODE TASK 11\]  Critzer's Cabinets site \+ AI agent New repo sprint. Premium redesign. AI sales agent build. Product database to 7k+. This is separate from shauncritzer.com — treat as its own focused project. |
| :---- |

## **Month 3 — The Engine as Product**

| \[STRATEGY\]  Document the engine, build onboarding, get 3 beta clients Your two businesses running autonomously are the proof. Build the SaaS onboarding flow. Find 3 beta clients (network first). Document everything the engine does as the product pitch. |
| :---- |

| PART 5: YOUR DAILY WORKFLOW — 30 MINUTES OR LESS |
| :---- |

| 🎯 GOAL:  Your daily involvement drops from hours to 30 minutes. Everything else runs autonomously. |
| :---- |

## **Daily Routine — Once System Is Running**

7. **Morning Briefing (5 min):** Open Mission Control. Read the daily briefing. AI tells you what it did, what performed well, what needs attention.

8. **Tier 3-4 Approvals (5 min):** Review any pending approvals. YES or NO. If it's recovery/fitness/transformation content — Yes. If it's spending over $100 — evaluate. If it's pivoting your niche — No.

9. **LangSmith Check (5 min):** Spot-check agent runs. Look for failures or unexpected behavior. Early on this is 10 minutes. Eventually once stable it's a quick scan.

10. **One Code Task (15 min):** Follow the anti-loop protocol. One item from AGENT\_DIRECTIVE.md. Open Code, paste the opener, let it execute, confirm it worked.

11. **Human Touchpoints (varies):** Showroom appointments (cabinets). Field measurements (cabinets). AA sponsoring and speaking. Memoir finalization. These are the things only you can do.

## **Weekly Rhythm**

| Every Monday Review weekly performance report (AI generates it) Set content focus for the week in Mission Control command box Check revenue dashboard — Stripe \+ ConvertKit stats Update AGENT\_DIRECTIVE.md with new priorities | Every Friday Review what the agent learned (LangSmith weekly summary) Check if any integrations need attention (Diagnostics page) 30-minute strategy session with Claude.ai for next week Approve/deny any accumulated Tier 3 items |
| :---- | :---- |

## **The AI vs You Split — Final State**

| 🤖 AI RUNS PERMANENTLY | 👤 SHAUN HANDLES |
| ----- | ----- |
| All content creation \+ publishing Lead capture \+ email nurturing Sales processing (Stripe) Performance monitoring Course video generation Customer first-contact (AI Coach) Research \+ competitive intel Social media monitoring Affiliate tracking | Daily 30-min briefing review Tier 3-4 approval decisions Showroom appointments (cabinets) Field dimension verification Speaking \+ AA sponsoring Memoir — the human story Strategic direction (quarterly) Relationship building Claude Cote partnership |

| PART 6: THE MILLION DOLLAR PATH |
| :---- |

## **Conservative Revenue Projections**

| Period | Start | Target | Driver | What Needs to Happen |
| :---- | :---- | :---- | :---- | :---- |
| **Month 1-3** | $0 | **$3,000/mo** | Personal brand | Scheduler fixed, 7-Day Reset on sale, memoir live, posting daily |
| **Month 4-6** | $3k | **$15,000/mo** | Brand \+ Cabinets | 30-Day course live, cabinets AI agent converting, email sequences running |
| **Month 7-9** | $15k | **$40,000/mo** | All three | SaaS first 3-5 clients, both businesses autonomous, case studies published |
| **Month 10-12** | $40k | **$85,000/mo** | Scale | SaaS at 20+ clients, cabinets waitlist, brand at $25k/mo recurring |
| **Year 2** | $85k | **$200k+/mo** | Methodology | SaaS 50+ clients, REWIRED licensing to institutions, engine proven at scale |

| 💰 THE CABINET REALITY CHECK:  3 additional AI-converted cabinet jobs per month \= $45,000-$150,000 incremental revenue. This is your single biggest financial opportunity and it's a 40-year business you already own. The digital brand builds the authority. The cabinets build the wealth. |
| :---- |

| 🚀 THE MOONSHOT:  First fully autonomous AI agent operation to generate $1M with minimal human input. Every dollar is a data point. Every automated post, every course sale, every AI-converted cabinet lead is proof the engine works. That proof is what you sell to the world. |
| :---- |

| *The plumbing works. The products exist. The story is real. Execution discipline for 90 days is the only variable.* Shaun Critzer · Master Blueprint · Updated March 2026 |
| :---: |

