**SHAUN CRITZER EMPIRE**

Complete System Summary

*As of March 11, 2026 — Built on AI*

# **THE VISION**

Three interconnected businesses, all powered by the same autonomous AI engine. The personal brand proves the engine works. The cabinet business generates immediate revenue. The engine itself becomes the product you sell to the world.

*The moonshot: the first fully autonomous AI agent operation to generate $1M with minimal human input. Every automated post, every course sale, every AI-converted cabinet lead is proof the engine works. That proof is what you sell.*

# **BUSINESS 1: SHAUN CRITZER BRAND**

shauncritzer.com — Recovery, fitness, transformation, speaking, digital products

Your personal brand is the live case study. It proves the AI engine works by running your content creation, email nurturing, course delivery, and community management autonomously. You are positioned as "the transformation guy" — not narrowly the addiction guy — which keeps ad platforms happy and broadens your market.

## **Your Story (The Credibility Anchor)**

You are Shaun Critzer. 13+ years sober. Former Mr. Teen USA (1998). Survived childhood sexual abuse, alcohol addiction, process addictions (porn, affairs, obsessive bodybuilding), DUIs, protective orders, psychiatric hospitalizations, and suicidal ideation. Got sober January 1, 2013\. Did EMDR therapy, 12 steps with rigorous honesty, and rebuilt everything. Married to Shannon. Father to Landon, Cameron, and stepson Brody. Peaceful co-parenting with ex-wife. Based in Virginia.

Your memoir "Crooked Lines: Bent, Not Broken" is 70,000+ words, complete, and serves as the credibility anchor for the entire brand. It is not yet published on Amazon KDP.

## **The REWIRED Methodology**

Your proprietary framework for nervous system-based recovery:

* R — Recognize nervous system dysregulation

* E — Establish safety and grounding

* W — Work through trauma with compassion

* I — Integrate new patterns and beliefs

* R — Rebuild relationships and purpose

* E — Embrace ongoing growth

* D — Develop sustainable recovery practices

Core thesis: addiction is not moral failure — it is nervous system dysregulation. Willpower fails because you are fighting biology. Somatic practices, breathwork, grounding, therapy, and community actually rewire the nervous system.

## **Products & Revenue Streams**

**1\. Crooked Lines: Bent, Not Broken — $19.99**

The memoir. 70,000+ words. Complete manuscript. Needs final editing pass and Amazon KDP upload. Also sold via Stripe on the website. Includes reading guide and first-3-chapters lead magnet. This is the credibility anchor that makes everything else sell.

**2\. 7-Day REWIRED Reset — $47**

The entry-level course. 7 video lessons covering nervous system basics, shame release, trigger mapping, somatic tools, process addictions, relapse prevention, and building a recovery toolkit. Scripts complete (78,000 words total across all courses). Videos need HeyGen generation. Workbooks created. Stripe checkout live and working. THIS IS READY TO SELL once videos are generated.

**3\. From Broken to Whole — $97**

The deep-dive 30-day transformation course. 30 video lessons across 8 modules: Understanding Your Story, Nervous System Healing, Shame and Self-Compassion, Inner Child Work, Relationship Rebuilding, Purpose and Meaning, Spiritual Awakening, and Integration. Scripts complete. Videos need generation. Stripe checkout live.

**4\. Bent Not Broken Circle — $29/month**

Monthly membership community. Live group coaching calls, private forum, weekly accountability, exclusive content, guest experts. Launches after 50 course sales. Custom-built forum \+ Discord integration planned (avoiding Circle.so/Kajabi monthly fees until revenue justifies it). Stripe checkout live.

**5\. AI Recovery Coach — Free (lead magnet)**

AI chatbot trained on the REWIRED methodology. Deployed on Vercel. 10 free messages per user, then paywall to From Broken to Whole course. Black background with gold accents. Serves as the primary email capture mechanism. Already built and live at shauncritzer.com/ai-coach.

**6\. REWIRED Methodology License — $2K-$5K (Year 2\)**

License the REWIRED framework to other coaches, therapists, treatment centers. Not built yet. Depends on brand authority established by everything above.

**7\. Living Sober / "REWIRED Daily" — TBD**

50+ practical recovery tips organized in 6 sections. Complete manuscript. Could be standalone $9.99 product or bonus with the $97 course. Needs renaming since "Living Sober" is taken by AA.

## **Content Assets (Complete)**

* 37 video scripts — 78,000 words total, ready for HeyGen avatar generation

* 5 blog posts seeded on the site (sobriety vs recovery, childhood abuse, armor metaphor, EMDR therapy, co-parenting)

* Recovery Toolkit PDF — worksheets, daily check-ins, trigger plans, gratitude templates, relapse prevention

* Reading Guide PDF — book club companion for the memoir

* First 3 Chapters PDF — lead magnet for email capture

* Community Guidelines — complete for Bent Not Broken Circle

* 31 email scripts across 7 ConvertKit sequences (written, NOT yet imported)

## **Website Pages (Live)**

* Homepage — memoir hero, email capture, product overview

* About — full personal story, family photos, mission statement

* Memoir — book details, early praise, first chapters download

* Blog — 5 posts with recovery/trauma/growth themes

* Resources — free downloadable PDFs (toolkit, reading guide)

* Products — all 4 products with Stripe checkout

* AI Coach — REWIRED chatbot with freemium model

* Members portal — course access after purchase, progress tracking

* Admin — seed data, manage videos, diagnostics

# **BUSINESS 2: CRITZER'S CABINETS**

critzerscabinets.com — 40-year family business, kitchen & bath, 4,000 sq ft showroom, Virginia

This is the single biggest immediate financial opportunity. Average kitchen: $15K-$50K. Average bath: $8K-$20K. Three additional AI-converted jobs per month \= $45,000-$150,000 incremental revenue. The digital brand builds authority. The cabinets build wealth.

## **What Gets Built**

* Premium website redesign

* AI sales agent (questions → quote → order)

* 7,000+ product database (1,000 items started)

* AI CAD room designer (future)

* Manufacturer API integration (future)

* Dimension scanning app integration (exists)

## **Your Role**

* Showroom relationship appointments

* Field dimension verification

* Installation coordination

Separate repo from shauncritzer.com. Treated as its own focused project. Timeline: Month 2-3 of the blueprint.

# **BUSINESS 3: THE ENGINE (SaaS — Name TBD)**

The autonomous business operating system that runs Business 1 and 2\. Then you sell it to the world.

## **What You Sell**

* Done-for-you autonomous business deployment — $5K-$15K setup \+ $2K-$5K/month managed

* Self-serve SaaS tiers: Starter $297/mo, Growth $697/mo, Enterprise $1,997/mo, Agency $4,997/mo

* White-label for agencies

## **The Case Study Pitch**

*"We built this to run a recovery coach's brand and a 40-year cabinet company. Both now run autonomously. Here's the revenue. Want this for your business?"*

10 managed clients \= $20K-$50K/month. 30 managed clients \= $60K-$150K/month. Pure margin, no inventory, no showroom.

# **THE TECH STACK**

## **Hosting & Infrastructure**

* Railway — main app hosting (Node.js), n8n service, PostgreSQL, MySQL

* GitHub — source code repository, both agents have access

* Cloudflare R2 — media/asset storage (cheap and fast)

* Vercel — AI Recovery Coach deployment (separate from main site)

## **Payments & Email**

* Stripe (LIVE mode) — all 4 products active, webhooks connected

* ConvertKit — email marketing, subscriber management, automation rules

## **AI & Content Creation**

* Claude API (Sonnet for quality tasks, Haiku for bulk/cheap) — content generation, agent decisions

* HeyGen (1,500 credits) — AI avatar video generation for course lessons

* ElevenLabs — voice cloning for course narration

* Flux via Replicate — image generation (replacing DALL-E, better quality, cheaper)

* Ideogram — text-in-image for quote graphics

## **Automation & Orchestration**

* n8n (self-hosted on Railway, PostgreSQL backend) — workflow triggers and scheduling, replaces Make.com

* LangGraph — agent orchestration backbone (Week 2 task, not yet wired)

* Tavily — web research API for trending topics and competitor intel

* Browserbase — cloud browser automation (paid, connected)

* Firecrawl — deep site scraping when Tavily isn't enough

## **Observability & Memory**

* LangSmith — agent observability, see every decision and failure (Week 2 task)

* Supabase pgvector — agent memory, stores what content worked (Week 2 task)

## **Development Tools**

* Claude.ai (this) — THE ARCHITECT: strategy, diagnosis, Code briefs, decision-making

* Claude Code (desktop, Opus model) — THE BUILDER: executes tasks, fixes bugs, deploys

* Cowork — THE EXECUTOR: desktop automation, file management, local tasks

* Manus AI — asset management, used for initial build (now secondary to Claude Code for business logic)

## **Database Schema**

* Users — email, login method, created date

* Purchases — user\_id, product\_id, amount, status, Stripe reference

* Course Modules — product\_id, title, description, order

* Course Lessons — module\_id, title, description, video\_url, duration, order, completion tracking

* Blog Posts — title, content, category, published date

* Lead Magnets — title, description, download URL

* Social Posts — content, platform, status (Draft → Ready → Published → Failed), scheduled time

# **CURRENT STATUS (March 11, 2026\)**

## **What Works Right Now**

✅ **Stripe checkout —** All 4 products live and processing payments

✅ **n8n scheduler —** Hourly workflow firing, calling /api/scheduler/run, green

✅ **Website —** All pages live — home, about, memoir, blog, resources, products, AI coach, members

✅ **AI Recovery Coach —** Live on Vercel, 10-message freemium, paywall working

✅ **Social posting pipeline —** Ready → Published scheduler bug fixed

✅ **Niche restriction —** Locked to 9 brand verticals (recovery, fitness, transformation, etc.)

✅ **Video module\_id bug —** Fixed — orphaned lesson FK references now auto-repair

✅ **Course lesson database —** 37 lessons seeded with scripts

✅ **Blog —** 5 posts live

✅ **Lead magnets —** 3 PDFs downloadable (first chapters, toolkit, reading guide)

## **What's NOT Done Yet**

❌ **Course videos —** 37 scripts ready but NO videos generated in HeyGen yet

❌ **ConvertKit sequences —** 31 emails written but NOT imported into ConvertKit

❌ **Memoir on Amazon —** Manuscript complete but NOT uploaded to KDP

❌ **LangGraph orchestration —** Not wired — Week 2 task

❌ **Supabase pgvector memory —** Not set up — Week 2 task

❌ **LangSmith observability —** Not connected — Week 2 task

❌ **Flux image generation —** Not replacing DALL-E yet — Week 2-3 task

❌ **Browserbase feedback loop —** Not built — Week 4 task

❌ **Critzer's Cabinets site —** Separate project, Month 2-3

❌ **The Engine SaaS —** Month 3+, requires both businesses running autonomously first

❌ **Community forum —** Not built, launches after 50 course sales

# **THE TEAM**

* Shaun Critzer — founder, face of brand, content voice, showroom appointments, strategic direction

* Michael Der — tech partner, San Francisco, Digital Gravity co-founder

* VAs — India and Philippines, operational tasks across time zones

* Closer — Canada, sales

* Claude.ai — strategy, planning, brief writing (this conversation)

* Claude Code — development, deployment, bug fixes

# **SOCIAL PRESENCE**

* Facebook — 4,200+ friends (mix of family, digital marketers, recovery contacts)

* TikTok — @freedomwithshaun, several thousand followers

* Instagram — small but growing

* Business Facebook — separate page

* freedomwithshaun.com — solo ads business (separate revenue stream)

# **REVENUE TARGETS**

**Month 1-3:** $500 → $3,000/month — Personal brand. Scheduler posting daily, 7-Day Reset on sale, memoir live.

**Month 4-6:** $3,000 → $15,000/month — Brand \+ Cabinets. 30-Day course live, cabinets AI agent converting, email sequences running.

**Month 7-9:** $15,000 → $40,000/month — All three. SaaS first 3-5 clients, both businesses autonomous, case studies published.

**Month 10-12:** $40,000 → $85,000/month — Scale. SaaS 20+ clients, cabinets waitlist, brand at $25K/mo recurring.

**Year 2:** $85,000 → $200,000+/month — SaaS 50+ clients, REWIRED licensing to institutions, engine proven at scale.

# **90-DAY BUILD SEQUENCE STATUS**

## **Week 1 — Make It Actually Post**

✅ **\[CODE\] Fix Ready → Published scheduler bug —** DONE

✅ **\[CODE\] Install n8n on Railway \+ replace Make.com —** DONE

✅ **\[CODE\] Fix video module\_id mismatch —** DONE

❌ **\[YOU\] Import ConvertKit sequences (31 emails, 7 sequences, 6 rules) —** NOT DONE — this is your next task

## **Week 2 — Make It Actually Think**

❌ **\[CODE\] Wire LangGraph as orchestration layer —** Not started

❌ **\[CODE\] Add Supabase pgvector for agent memory —** Not started

❌ **\[CODE\] Add LangSmith observability —** Not started

## **Week 3 — Make It Actually Sell**

❌ **\[LAUNCH\] 7-Day Reset goes on sale — $47 —** Blocked on video generation \+ ConvertKit

❌ **\[CODE\] Replace DALL-E with Flux via Replicate —** Not started

❌ **\[YOU\] Memoir final edits \+ Amazon KDP upload —** Not started

## **Week 4 — Make It Actually Learn**

❌ **\[CODE\] Browserbase engagement feedback loop —** Not started

✅ **\[CODE\] Restrict niche research to brand verticals —** DONE (completed early)

## **Month 2 — Course Videos \+ Cabinets**

❌ **\[CODE\] Complete 30-Day course video pipeline —** Blocked on HeyGen generation

❌ **\[CODE\] Critzer's Cabinets site \+ AI agent —** Not started

## **Month 3 — The Engine as Product**

❌ **\[STRATEGY\] Document engine, build onboarding, get 3 beta clients —** Not started

# **YOUR ONE TASK TODAY**

**Open ConvertKit. Import the Welcome sequence (5 emails). Set a 25-minute Pomodoro timer. Paste the emails. That is the only thing standing between you and the end of Week 1\.**

*— End of System Summary —*